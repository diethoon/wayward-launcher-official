package com.wayward.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.ClearTokenRequest;
import com.google.android.gms.auth.api.identity.RevokeAccessRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_TREE=4101, PICK_MOD_ZIP=4102, REQUEST_NAI_SETTINGS=4104;
    private static final int REQUEST_GOOGLE_AUTH_MIN=60000, REQUEST_GOOGLE_AUTH_MAX=65534;
    private static final String PREFS="wayward_launcher";
    private static final String KEY_TREE="game_tree_uri", KEY_PROFILES="game_profiles", KEY_ZIP_REV="zip_mod_revision", KEY_COMFY_URL="comfy_server_url", KEY_IMAGE_MODE="image_server_mode";
    private static final String IMAGE_MODE_PACKS_ONLY="image-packs-only", IMAGE_MODE_GENERATION="image-generation", IMAGE_MODE_REMOTE_PC="remote-pc";
    private static final String KO="Wayward_WML_ko.html", EN="Wayward_WML.html";
    private static final Pattern ID=Pattern.compile("^[a-z0-9][a-z0-9._-]*$");
    private static final Set<String> RUNNING_SESSIONS=Collections.synchronizedSet(new HashSet<>());
    private static final Map<String,String> PENDING_GOOGLE_AUTH_RESULTS=new ConcurrentHashMap<>();
    // Keep weak references to the Activity that owns each active game WebView and SAF tree.
    // Keep weak references so settings actions can return to the Activity that
    // actually owns the active game's WebView and SAF tree.
    private static final Map<String, WeakReference<MainActivity>> SESSION_ACTIVITIES =
            new ConcurrentHashMap<>();
    private static volatile String LAST_ACTIVE_SESSION_ID = "";
    private static final String EXTRA_OPEN_IMAGE_STUDIO_SETTINGS =
            "com.wayward.launcher.OPEN_IMAGE_STUDIO_SETTINGS";
    private static final String EXTRA_GAME_LAUNCH_REQUEST_ID =
            "com.wayward.launcher.GAME_LAUNCH_REQUEST_ID";
    private static final Pattern MOD_ID=Pattern.compile("(?:\\bid\\s*:\\s*|[\\\"']id[\\\"']\\s*:\\s*)[\\\"']([a-z0-9][a-z0-9._-]*)[\\\"']");
    private Uri treeUri;
    private SafTree tree;
    private ZipModStore zipMods;
    private final List<GameProfile> profiles=new ArrayList<>();
    private String activeProfileId="";
    private String pendingGoogleAuthNonce="";
    private int nextGoogleAuthRequestCode=REQUEST_GOOGLE_AUTH_MIN;
    private final Map<Integer,String> pendingGoogleAuthRequestNonces=new ConcurrentHashMap<>();
    private long loadedZipRevision=-1;
    private FrameLayout root;
    private LinearLayout home, profileList, zipModList;
    private TextView status, folderText, profileSummary, zipSummary, imageGenStatus, imageModeStatus;
    private LinearLayout imageModePanel;
    private EditText comfyUrlInput;
    private boolean imageModeTransitionInProgress=false;
    private boolean startImageServerAfterNaiSettings=false;
    private final ImageServerModeCoordinator imageServerModeCoordinator=new ImageServerModeCoordinator();
    public interface RemotePcServerControl {
        void stop(ImageServerModeCoordinator.Callback callback);
        void start(ImageServerModeCoordinator.Callback callback);
    }
    private static volatile RemotePcServerControl remotePcServerControl;
    public static void registerRemotePcServerControl(RemotePcServerControl control){ remotePcServerControl=control; }
    private String imageGenSessionMessage = "";
    private boolean imageStudioSessionDetected = false;
    private boolean pendingOpenImageStudioSettings = false;
    private static volatile boolean imageGenCopying = false;
    private static volatile boolean manualImageGenPreparing = false;
    private final Handler imageGenHandler = new Handler(Looper.getMainLooper());
    private final List<Runnable> imageGenReadyCallbacks = new ArrayList<>();
    private Runnable imageGenPollRunnable;
    private WebView web;
    private final String activityInstanceId = UUID.randomUUID().toString();
    private String activeGameLaunchRequestId = "";
    private String webViewInstanceId = "";
    private int webViewGeneration = 0;
    private boolean gamePageLoaded = false;
    private boolean gamePageLoadFailed = false;
    private WebFileChooser webFileChooser;
    private WebDownloadHandler webDownloadHandler;
    private String waywardDownloadBridgeScript;
    private String waywardDownloadBridgeOrigin = "";
    private boolean waywardDownloadBridgeDocumentStartRegistered;
    private ImagePackDirectoryAccess imagePackDirectoryAccess;
    private String imagePackDiagnosticSessionId = "";
    private String imagePackFolderPickerScript;
    private String imagePackFolderPickerOrigin = "";
    private String imagePackFolderPickerCapability = "";
    private Button pairingButton;
    private RemoteHostDiscovery remoteHostDiscovery;
    private boolean remoteReconnectInProgress;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        String sessionId=sessionProfileId(getIntent());
        String requestId=getIntent().getStringExtra(EXTRA_GAME_LAUNCH_REQUEST_ID);
        activeGameLaunchRequestId=requestId==null?"":requestId;
        logGameLifecycle("INFO","activity_create",sessionId,activeGameLaunchRequestId,
                sessionId==null?"launcher_intent":"game_session_intent");
        registerRemotePcControl();
        zipMods=new ZipModStore(getFilesDir());
        loadProfiles();
        showHome();
        if(sessionId!=null)openProfileSession(sessionId);
        else refreshStatus();
    }
    @Override protected void onResume(){
        super.onResume();
        if(web!=null)web.onResume();
        DiagnosticsUploader.uploadPending(this);
        if(imagePackDirectoryAccess!=null)imagePackDirectoryAccess.onResume();
        logGameLifecycle("INFO","activity_resume",sessionProfileId(getIntent()),
                activeGameLaunchRequestId,"onResume");
        loadProfiles();
        long revision=getSharedPreferences(PREFS,MODE_PRIVATE).getLong(KEY_ZIP_REV,0);
        if(web!=null&&revision!=loadedZipRevision){loadedZipRevision=revision;web.reload();}
        if(web!=null&&tree!=null)registerSessionActivity();
        if(home!=null&&home.getVisibility()==View.VISIBLE){
            renderProfiles();refreshStatus();refreshImageGenStatus();renderImageModePanel();
            updatePairingButtonState();
            startRemoteHostDiscoveryIfNeeded();
            reconnectRemoteHostInBackground();
        }
    }
    @Override protected void onPause(){
        logGameLifecycle("INFO","activity_pause",sessionProfileId(getIntent()),
                activeGameLaunchRequestId,"onPause");
        if(imagePackDirectoryAccess!=null)imagePackDirectoryAccess.onPause();
        if(web!=null)web.onPause();
        if(remoteHostDiscovery!=null){
            try{remoteHostDiscovery.close();}catch(Exception ignored){}
            remoteHostDiscovery=null;
        }
        super.onPause();
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);setIntent(intent);
        String sessionId=sessionProfileId(intent);
        String requestId=intent==null?null:intent.getStringExtra(EXTRA_GAME_LAUNCH_REQUEST_ID);
        if(requestId!=null&&!requestId.isEmpty())activeGameLaunchRequestId=requestId;
        logGameLifecycle("INFO","activity_new_intent",sessionId,activeGameLaunchRequestId,
                "onNewIntent");
        if(sessionId==null)return;
        if(sessionId.equals(activeProfileId)&&web!=null){
            showGameSession("existing_activity_new_intent");
        }else openProfileSession(sessionId);
    }
    private static final class GameProfile{
        final String id,uri,label;
        GameProfile(String i,String u,String n){id=i;uri=u;label=n;}
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void applySystemBarInsets(View target){
        if (Build.VERSION.SDK_INT < 35) return;
        final int baseLeft=target.getPaddingLeft();
        final int baseTop=target.getPaddingTop();
        final int baseRight=target.getPaddingRight();
        final int baseBottom=target.getPaddingBottom();
        target.setOnApplyWindowInsetsListener((view,insets)->{
            android.graphics.Insets safeInsets=insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            view.setPadding(baseLeft+safeInsets.left,baseTop+safeInsets.top,
                    baseRight+safeInsets.right,baseBottom+safeInsets.bottom);
            return insets;
        });
        target.requestApplyInsets();
    }
    private void status(String s){if(status!=null)status.setText(s);}
    private LinearLayout.LayoutParams buttonParams(){return new LinearLayout.LayoutParams(-1,dp(46));}
    private android.graphics.drawable.GradientDrawable uiShape(int fill,int stroke,float radius){
        android.graphics.drawable.GradientDrawable shape=new android.graphics.drawable.GradientDrawable();
        shape.setColor(fill);shape.setCornerRadius(dp(radius));
        if(stroke!=0)shape.setStroke(dp(1),stroke);
        return shape;
    }
    private LinearLayout uiCard(){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13),dp(12),dp(13),dp(12));
        card.setBackground(uiShape(Color.WHITE,Color.rgb(229,232,235),16));
        return card;
    }
    private TextView uiText(String value,float size,int color,boolean bold){
        TextView text=new TextView(this);text.setText(value);text.setTextSize(size);text.setTextColor(color);
        text.setIncludeFontPadding(false);
        if(bold)text.setTypeface(null,android.graphics.Typeface.BOLD);
        return text;
    }
    private void gap(LinearLayout parent,int height){
        View spacer=new View(this);parent.addView(spacer,new LinearLayout.LayoutParams(1,dp(height)));
    }
    private Button button(String label,boolean primary,Runnable run){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);
        b.setTextColor(Color.rgb(48,66,84));
        b.setPadding(dp(12),dp(5),dp(12),dp(5));b.setMinHeight(dp(42));
        GlassButtonStyle.bind(this,b,false,12f);
        b.setOnClickListener(v->run.run());return b;
    }
    private Button compactButton(String label,boolean primary,Runnable action){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);
        b.setTextColor(Color.rgb(48,66,84));b.setPadding(dp(9),dp(3),dp(9),dp(3));
        b.setMinHeight(dp(36));
        GlassButtonStyle.bind(this,b,false,10f);
        b.setOnClickListener(v->action.run());return b;
    }
    private void shareDiagnosticsZip(){
        ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "", "diagnostics_share_button_tapped",
                "info", null);
        if (DiagnosticsBundleUploader.isUploading()) {
            Toast.makeText(this, "진단 로그를 전송 중입니다. 잠시 후 다시 시도하세요.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            File archive = DiagnosticsBundleUploader.findPendingArchive(this);
            boolean retrying = archive != null;
            if (!retrying) archive = DiagnosticsBundleExporter.create(this);
            final File selectedArchive = archive;
            ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "",
                    "diagnostics_cloud_upload_requested", "info",
                    new JSONObject().put("fileSize", selectedArchive.length())
                            .put("retryingPreviousZip", retrying));
            DiagnosticsBundleUploader.upload(this, selectedArchive, (success, result) -> {
                if (isFinishing() || isDestroyed()) return;
                JSONObject details = new JSONObject();
                try {
                    details.put("success", success);
                    details.put("result", result == null ? "" : result);
                    details.put("fileSize", selectedArchive.length());
                    details.put("retryingPreviousZip", retrying);
                } catch (Exception ignored) {}
                ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "",
                        success ? "diagnostics_cloud_upload_succeeded" : "diagnostics_cloud_upload_failed",
                        success ? "info" : "error", details);
                String message = success
                        ? (retrying ? "이전 진단 ZIP 재전송 완료" : "진단 로그 자동 전송 완료")
                        : "진단 로그 자동 전송 실패 · 다음 진단 버튼 터치 시 같은 ZIP 재전송";
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            });
            // Preserve the existing Android share sheet using the exact same ZIP.
            DiagnosticsBundleExporter.share(this, selectedArchive);
            ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "", "diagnostics_share_chooser_opened",
                    "info", null);
        } catch (Exception error) {
            ImagePackDiagnostics.error(this, imagePackDiagnosticSessionId, "",
                    "diagnostics_share_failed", error);
            Toast.makeText(this, "진단 ZIP 수집 실패: " + msg(error), Toast.LENGTH_LONG).show();
        }
    }

    private void showHome(){
        root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(246,247,248));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(13),dp(16),dp(24));scroll.addView(page);

        LinearLayout top=new LinearLayout(this);top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title=uiText("WAYWARD",17,Color.rgb(24,27,31),true);
        title.setLetterSpacing(0.005f);
        title.setSingleLine(true);
        title.setHorizontallyScrolling(true);
        top.addView(title,new LinearLayout.LayoutParams(0,-2,1f));
        Button pcFolder=compactButton("+ PC 폴더",false,this::chooseRemotePcFolder);
        LinearLayout.LayoutParams pcFolderParams=new LinearLayout.LayoutParams(dp(76),dp(38));
        pcFolderParams.leftMargin=dp(4);top.addView(pcFolder,pcFolderParams);
        Button addFolder=compactButton("+ 현재 기기 폴더",true,this::chooseFolder);
        LinearLayout.LayoutParams addFolderParams=new LinearLayout.LayoutParams(dp(112),dp(38));
        addFolderParams.leftMargin=dp(4);top.addView(addFolder,addFolderParams);
        pairingButton=compactButton("페어링",false,this::openRemotePairing);
        LinearLayout.LayoutParams pairingParams=new LinearLayout.LayoutParams(dp(76),dp(38));
        pairingParams.leftMargin=dp(4);top.addView(pairingButton,pairingParams);
        Button diagnostics=compactButton("진단",false,this::shareDiagnosticsZip);
        LinearLayout.LayoutParams diagnosticsParams=new LinearLayout.LayoutParams(dp(48),dp(38));
        diagnosticsParams.leftMargin=dp(4);top.addView(diagnostics,diagnosticsParams);
        LinearLayout.LayoutParams topParams=new LinearLayout.LayoutParams(-1,-2);topParams.bottomMargin=dp(3);
        page.addView(top,topParams);
        TextView subtitle=uiText("GAME LAUNCHER  ·  여러 게임을 독립 세션으로 실행",11,Color.rgb(111,118,125),false);
        subtitle.setLetterSpacing(0.025f);page.addView(subtitle);

        LinearLayout statusCard=uiCard();
        LinearLayout.LayoutParams statusParams=new LinearLayout.LayoutParams(-1,-2);
        statusParams.topMargin=dp(13);statusParams.bottomMargin=dp(16);page.addView(statusCard,statusParams);
        status=uiText("런처 상태 확인 중",12,Color.rgb(35,39,43),true);
        statusCard.addView(status);
        folderText=uiText("",11,Color.rgb(113,120,127),false);
        LinearLayout.LayoutParams folderParams=new LinearLayout.LayoutParams(-1,-2);folderParams.topMargin=dp(6);
        statusCard.addView(folderText,folderParams);

        LinearLayout gameHeader=new LinearLayout(this);gameHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView gamesTitle=uiText("내 게임",16,Color.rgb(27,30,34),true);
        gameHeader.addView(gamesTitle,new LinearLayout.LayoutParams(0,-2,1f));
        profileSummary=uiText("0개",11,Color.rgb(111,118,125),false);gameHeader.addView(profileSummary);
        LinearLayout.LayoutParams gameHeaderParams=new LinearLayout.LayoutParams(-1,-2);
        gameHeaderParams.bottomMargin=dp(8);page.addView(gameHeader,gameHeaderParams);
        profileList=new LinearLayout(this);profileList.setOrientation(LinearLayout.VERTICAL);page.addView(profileList);

        LinearLayout imageCard=uiCard();
        imageCard.setClipChildren(false);
        imageCard.setClipToPadding(false);
        imageCard.setBackground(uiShape(Color.rgb(239,241,243),Color.rgb(225,228,231),16));
        LinearLayout.LayoutParams imageCardParams=new LinearLayout.LayoutParams(-1,-2);
        imageCardParams.topMargin=dp(14);
        page.addView(imageCard,imageCardParams);
        LinearLayout imageHeader=new LinearLayout(this);
        imageHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView imageTitle=uiText("IMAGE ROUTING",10,Color.rgb(104,119,135),true);
        imageTitle.setLetterSpacing(0.08f);
        imageHeader.addView(imageTitle,new LinearLayout.LayoutParams(0,-2,1f));
        imageHeader.addView(uiText("서버 선택",10,Color.rgb(126,135,145),false));
        imageCard.addView(imageHeader);
        imageModeStatus=uiText("이미지 출력 모드 확인 중",11,Color.rgb(102,112,123),false);
        LinearLayout.LayoutParams imageStatusParams=new LinearLayout.LayoutParams(-1,-2);
        imageStatusParams.topMargin=dp(7);
        imageStatusParams.bottomMargin=dp(10);
        imageCard.addView(imageModeStatus,imageStatusParams);
        imageModePanel=new LinearLayout(this);
        imageModePanel.setOrientation(LinearLayout.VERTICAL);
        imageModePanel.setClipChildren(false);
        imageModePanel.setClipToPadding(false);
        imageCard.addView(imageModePanel,new LinearLayout.LayoutParams(-1,-2));

        Button remoteFileManager=compactButton("원격 PC 파일매니저",false,this::openRemotePcFileManager);
        LinearLayout.LayoutParams remoteFileManagerParams=new LinearLayout.LayoutParams(-1,dp(46));
        remoteFileManagerParams.topMargin=dp(12);
        page.addView(remoteFileManager,remoteFileManagerParams);

        home=page;root.addView(scroll,new FrameLayout.LayoutParams(-1,-1));setContentView(root);applySystemBarInsets(root);
        renderProfiles();refreshStatus();renderImageModePanel();refreshImageGenStatus();updatePairingButtonState();
    }


    private String currentImageMode(){
        return getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_IMAGE_MODE,IMAGE_MODE_PACKS_ONLY);
    }

    private boolean localImageServerActive(){
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        return state.isReady()||state.isAvailable()||state.isStarting();
    }

    private View glassModeTile(String title,String subtitle,boolean selected,
            Runnable settingsAction,Runnable action){
        LinearLayout tile=new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(android.view.Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(14),dp(8),dp(9),dp(8));
        GlassButtonStyle.bind(this,tile,selected,17f);
        tile.setClickable(true);
        tile.setFocusable(true);

        LinearLayout labels=new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView state=uiText(selected?"● 선택됨":"○ 대기",9,
                selected?Color.rgb(83,91,98):Color.rgb(126,133,139),true);
        TextView heading=uiText(title,14,Color.rgb(43,49,54),true);
        heading.setMaxLines(1);
        TextView detail=uiText(subtitle,10,Color.rgb(103,111,117),false);
        detail.setMaxLines(1);
        labels.addView(state);
        LinearLayout.LayoutParams headingParams=new LinearLayout.LayoutParams(-1,-2);
        headingParams.topMargin=dp(3);
        labels.addView(heading,headingParams);
        LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams(-1,-2);
        detailParams.topMargin=dp(2);
        labels.addView(detail,detailParams);
        tile.addView(labels,new LinearLayout.LayoutParams(0,-1,1f));

        if(settingsAction!=null){
            TextView gear=uiText("⚙",21,Color.rgb(91,99,105),false);
            gear.setGravity(android.view.Gravity.CENTER);
            gear.setContentDescription("NovelAI 토큰 설정");
            gear.setMinWidth(dp(48));
            gear.setMinHeight(dp(48));
            gear.setClickable(true);
            gear.setFocusable(true);
            gear.setOnClickListener(view->settingsAction.run());
            tile.addView(gear,new LinearLayout.LayoutParams(dp(48),-1));
        }
        tile.setContentDescription(title);
        tile.setOnClickListener(view->action.run());
        return tile;
    }

    private void renderImageModePanel(){
        if(imageModePanel==null)return;
        imageModePanel.removeAllViews();
        String mode=currentImageMode();
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        boolean active=state.isReady()||state.isAvailable()||state.isStarting();
        boolean generationSelected=IMAGE_MODE_GENERATION.equals(mode)&&active;
        boolean packsSelected=IMAGE_MODE_PACKS_ONLY.equals(mode);
        String token="";
        try{ token=NovelAiTokenStore.readToken(this); }catch(Exception ignored){}
        boolean tokenReady=token!=null&&!token.isEmpty();
        if(imageModeStatus!=null){
            String message;
            if(imageModeTransitionInProgress) message="서버 전환 중 · 기존 서버를 종료하고 새 모드를 적용합니다.";
            else if(imageGenSessionMessage!=null&&imageGenSessionMessage.startsWith("이미지 서버 전환 실패:")) message=imageGenSessionMessage;
            else if(IMAGE_MODE_REMOTE_PC.equals(mode)) message="PC Remote Server 모드 · 승인된 PC 폴더와 Host 경유 HTTPS를 사용합니다.";
            else if(generationSelected&&state.isReady()) message="이미지 생성 서버 실행 중 · 이미지 생성 요청은 런처 서버로 전달됩니다.";
            else if(generationSelected) message="이미지 생성 서버 준비 중 · 생성 경로를 연결하고 있습니다.";
            else if(IMAGE_MODE_GENERATION.equals(mode)&&!active) message="이미지 생성 서버가 중지되었습니다. 다시 실행하거나 이미지팩 모드로 전환하세요.";
            else message="이미지팩 전용 · 이 기기에 설치된 이미지팩만 탐색";
            imageModeStatus.setText(message);
        }

        LinearLayout serverRow=new LinearLayout(this);
        serverRow.setOrientation(LinearLayout.HORIZONTAL);
        serverRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        View server=glassModeTile(generationSelected?"이미지 생성 서버 실행 중":"이미지 생성 서버 실행",
                generationSelected?"NovelAI 연결됨 · 다시 터치하면 종료":(tokenReady?"토큰 등록됨 · 터치해 서버 실행":"토큰 미등록 · 눌러 계정 연결"),
                generationSelected,this::openNovelAiSettings,()->{
                    if(IMAGE_MODE_GENERATION.equals(currentImageMode())&&localImageServerActive()) switchToImagePacksOnly();
                    else switchToImageGenerationMode();
                });
        LinearLayout.LayoutParams serverParams=new LinearLayout.LayoutParams(0,dp(82),1f);
        serverRow.addView(server,serverParams);

        boolean remotePaired=RemoteHostStore.isPaired(this);
        boolean comfySelected=IMAGE_MODE_REMOTE_PC.equals(mode)&&remotePaired;
        View comfy=glassModeTile(comfySelected?"ComfyUI 연결됨":"ComfyUI 서버 실행",
                remotePaired?"PC Host 인증 · ComfyUI 권한 필요":"PC 페어링 필요",
                comfySelected,null,this::switchToRemoteComfyMode);
        LinearLayout.LayoutParams comfyParams=new LinearLayout.LayoutParams(0,dp(82),1f);
        comfyParams.leftMargin=dp(8);
        serverRow.addView(comfy,comfyParams);
        imageModePanel.addView(serverRow,new LinearLayout.LayoutParams(-1,-2));

        View packs=glassModeTile(packsSelected?"이미지팩만 사용 · 활성":"이미지팩만 사용",
                "이 기기에 설치된 이미지팩만 탐색",
                packsSelected,null,this::switchToImagePacksOnly);
        LinearLayout.LayoutParams packsParams=new LinearLayout.LayoutParams(-1,dp(72));
        packsParams.topMargin=dp(9);
        packsParams.bottomMargin=dp(4);
        imageModePanel.addView(packs,packsParams);

    }


    private void updatePairingButtonState(){
        if(pairingButton==null)return;
        boolean paired=RemoteHostStore.isPaired(this);
        pairingButton.setText(paired?"페어링 완료":"페어링");
        pairingButton.setEnabled(!paired);
        pairingButton.setAlpha(paired?0.68f:1.0f);
        pairingButton.setContentDescription(paired?"PC 페어링이 완료되었습니다":"PC QR 페어링 시작");
    }

    private void openRemotePairing(){
        if(RemoteHostStore.isPaired(this)){
            Toast.makeText(this,"이미 PC와 페어링되어 있습니다.",Toast.LENGTH_SHORT).show();
            updatePairingButtonState();
            return;
        }
        startActivity(new Intent(this,RemotePairingActivity.class));
    }

    private void showPcPairingRequired(String nextAction){
        new AlertDialog.Builder(this)
                .setTitle("PC 페어링 필요")
                .setMessage("PC Remote Server를 실행하고 Windows Manager에 표시된 QR을 런처 내부에서 스캔해야 합니다. 승인 후 PC에서 허용한 폴더만 사용할 수 있습니다.")
                .setNegativeButton("닫기",null)
                .setPositiveButton("페어링", (dialog,which)->openRemotePairing())
                .show();
    }

    private void chooseRemotePcFolder(){
        if(!RemoteHostStore.isPaired(this)){
            showPcPairingRequired("folder");
            return;
        }
        new Thread(()->{
            try{
                RemoteHostConnection host=RemoteHostStore.loadConnection(this);
                if(host==null)throw new IllegalStateException("등록된 PC Host가 없습니다.");
                RemoteHostClient.authenticate(this,host);
                JSONArray roots=RemoteHostClient.getWorkspaceRoots(this,host);
                if(roots.length()==0)throw new IllegalStateException("PC에서 승인된 폴더가 없습니다. Windows Manager에서 PC 폴더를 먼저 허용하세요.");
                String[] labels=new String[roots.length()];
                String[] ids=new String[roots.length()];
                for(int i=0;i<roots.length();i++){
                    JSONObject item=roots.getJSONObject(i);
                    ids[i]=item.getString("rootId");
                    labels[i]=item.optString("displayName",ids[i]);
                }
                runOnUiThread(()->new AlertDialog.Builder(this)
                        .setTitle("PC에서 허용한 폴더")
                        .setItems(labels,(dialog,which)->{
                            RemoteHostStore.saveSelectedRoot(this,ids[which],labels[which]);
                            Toast.makeText(this,"PC 폴더 선택: "+labels[which],Toast.LENGTH_SHORT).show();
                            renderImageModePanel();
                        })
                        .setNegativeButton("취소",null)
                        .show());
            }catch(Exception error){
                String detail=msg(error);
                if(isRemoteDeviceRevoked(error))RemoteHostStore.clearPaired(this,null);
                runOnUiThread(()->{
                    updatePairingButtonState();
                    new AlertDialog.Builder(this).setTitle("PC 폴더 조회 실패").setMessage(detail)
                            .setPositiveButton("확인",null).show();
                });
            }
        },"Wayward-Remote-Root-Picker").start();
    }

    private void openRemotePcFileManager(){
        if(!RemoteHostStore.isPaired(this)){
            showPcPairingRequired("files");
            return;
        }
        startActivity(new Intent(this,RemotePcFileManagerActivity.class));
    }

    private void switchToRemoteComfyMode(){
        if(!RemoteHostStore.isPaired(this)){
            showPcPairingRequired("comfy");
            return;
        }
        if(RemoteHostStore.getSelectedRootId(this).isEmpty()){
            chooseRemotePcFolder();
            Toast.makeText(this,"먼저 PC 폴더를 선택하세요.",Toast.LENGTH_SHORT).show();
            return;
        }
        imageModeStatus.setText("PC ComfyUI 서버 상태와 사용 권한 확인 중…");
        new Thread(()->{
            try{
                RemoteHostConnection host=RemoteHostStore.loadConnection(this);
                if(host==null)throw new IllegalStateException("PC Host 연결 정보가 없습니다.");
                JSONObject status=RemoteComfyClient.getStatus(this,host);
                runOnUiThread(()->{
                    switchToRemotePcServer();
                    Toast.makeText(this,"PC ComfyUI 서버 연결 확인 완료 · "+status.optString("system","준비됨"),Toast.LENGTH_LONG).show();
                });
            }catch(Exception error){
                String detail=msg(error);
                runOnUiThread(()->{
                    imageModeStatus.setText(detail.contains("403")
                            ?"PC에서 이 기기의 ComfyUI 사용 권한을 허용해야 합니다."
                            :"PC ComfyUI 연결 실패: "+detail);
                    Toast.makeText(this,imageModeStatus.getText(),Toast.LENGTH_LONG).show();
                });
            }
        },"Wayward-Remote-Comfy-Connect").start();
    }

    private boolean isRemoteDeviceRevoked(Exception error){
        String value=error==null?"":String.valueOf(error.getMessage()).toLowerCase(Locale.ROOT);
        return value.contains("http 401")||value.contains("http 404")||
                value.contains("devicerevoked")||value.contains("device_not_paired");
    }

    private void startRemoteHostDiscoveryIfNeeded(){
        if(!RemoteHostStore.isPaired(this)||remoteHostDiscovery!=null)return;
        try{
            RemoteHostDiscovery discovery=new RemoteHostDiscovery(this);
            discovery.start(new RemoteHostDiscovery.Listener(){
                @Override public void onHostAddressUpdated(RemoteHostConnection connection){
                    reconnectRemoteHostInBackground();
                }
                @Override public void onHostLost(String hostId){
                    if(imageModeStatus!=null)imageModeStatus.setText("PC 연결이 일시적으로 끊겼습니다. 동일 Host의 LAN 재검색을 계속합니다.");
                }
                @Override public void onDiscoveryError(String operation,Exception error){
                    DiagnosticsLogger.error(MainActivity.this,"remote-host","mdns_"+operation,error);
                }
            });
            remoteHostDiscovery=discovery;
        }catch(Exception error){
            DiagnosticsLogger.error(this,"remote-host","mdns_start",error);
        }
    }

    private void reconnectRemoteHostInBackground(){
        if(remoteReconnectInProgress||!RemoteHostStore.isPaired(this))return;
        remoteReconnectInProgress=true;
        new Thread(()->{
            String statusText="PC 연결이 준비되었습니다.";
            boolean revoked=false;
            try{
                RemoteHostConnection host=RemoteHostStore.loadConnection(this);
                if(host==null)throw new IllegalStateException("PC 연결 정보가 없습니다.");
                RemoteHostClient.authenticate(this,host);
                JSONArray roots=RemoteHostClient.getWorkspaceRoots(this,host);
                String selected=RemoteHostStore.getSelectedRootId(this);
                boolean selectedFound=false;
                for(int i=0;i<roots.length();i++){
                    JSONObject item=roots.optJSONObject(i);
                    if(item!=null&&selected.equals(item.optString("rootId",""))){selectedFound=true;break;}
                }
                statusText=selectedFound?"PC 영구 페어링 및 자동 재연결 완료":"PC에 연결됐습니다. PC 폴더를 선택하세요.";
            }catch(Exception error){
                revoked=isRemoteDeviceRevoked(error);
                statusText=revoked?"PC에서 이 기기의 등록이 해제되었습니다. 다시 페어링하세요.":"PC 자동 재연결 대기 중: "+msg(error);
            }finally{
                if(revoked)RemoteHostStore.clearPaired(this,null);
                String text=statusText;
                runOnUiThread(()->{
                    remoteReconnectInProgress=false;
                    updatePairingButtonState();
                    if(imageModeStatus!=null&&RemoteHostStore.isPaired(this))
                        imageModeStatus.setText(text);
                    renderImageModePanel();
                });
            }
        },"Wayward-Remote-Host-Reconnect").start();
    }

    private void registerRemotePcControl(){
        registerRemotePcServerControl(new RemotePcServerControl(){
            @Override public void stop(ImageServerModeCoordinator.Callback callback){
                RemoteHostClient.clearSession();
                callback.onSuccess();
            }
            @Override public void start(ImageServerModeCoordinator.Callback callback){
                new Thread(()->{
                    try{
                        RemoteHostConnection host=RemoteHostStore.loadConnection(MainActivity.this);
                        if(host==null)throw new IllegalStateException("먼저 PC Remote Host를 등록하세요.");
                        String rootId=RemoteHostStore.getSelectedRootId(MainActivity.this);
                        if(rootId==null||rootId.isEmpty())throw new IllegalStateException("PC 게임 폴더를 선택하세요.");
                        RemoteHostClient.authenticate(MainActivity.this,host);
                        org.json.JSONArray roots=RemoteHostClient.getWorkspaceRoots(MainActivity.this,host);
                        boolean found=false;
                        for(int i=0;i<roots.length();i++){
                            org.json.JSONObject root=roots.optJSONObject(i);
                            if(root!=null&&rootId.equals(root.optString("rootId",""))){found=true;break;}
                        }
                        if(!found)throw new IllegalStateException("PC에서 선택한 허용 폴더를 더 이상 찾을 수 없습니다. 폴더를 다시 선택하세요.");
                        runOnUiThread(callback::onSuccess);
                    }catch(Throwable error){
                        runOnUiThread(()->callback.onFailure(msg(error)));
                    }
                },"Wayward-RemoteHost-Connect").start();
            }
        });
    }

    private void openNovelAiSettings(){
        startActivityForResult(new Intent(this,NovelAiSettingsActivity.class),REQUEST_NAI_SETTINGS);
    }

    private void switchToImageGenerationMode(){
        String token="";
        try{ token=NovelAiTokenStore.readToken(this); }
        catch(Exception error){
            imageGenSessionMessage="NAI 토큰 저장소를 읽지 못했습니다: "+msg(error);
            renderImageModePanel();
            return;
        }
        if(token==null||token.isEmpty()){
            startImageServerAfterNaiSettings=true;
            openNovelAiSettings();
            return;
        }
        switchImageServerMode(ImageServerModeCoordinator.Mode.LOCAL_IMAGE_GENERATION);
    }

    private void switchToImagePacksOnly(){
        switchImageServerMode(ImageServerModeCoordinator.Mode.IMAGE_PACKS_ONLY);
    }

    /** Future home-PC pairing must call this same transition path before starting its service. */
    public void switchToRemotePcServer(){
        switchImageServerMode(ImageServerModeCoordinator.Mode.REMOTE_PC);
    }

    private void switchImageServerMode(ImageServerModeCoordinator.Mode target){
        if(imageModeTransitionInProgress)return;
        imageModeTransitionInProgress=true;
        renderImageModePanel();
        imageServerModeCoordinator.switchTo(target,new ImageServerModeCoordinator.Operations(){
            @Override public void stopRemote(ImageServerModeCoordinator.Callback callback){
                RemotePcServerControl control=remotePcServerControl;
                if(control==null){callback.onSuccess();return;}
                try{control.stop(callback);}catch(Throwable error){callback.onFailure(msg(error));}
            }
            @Override public void stopLocal(ImageServerModeCoordinator.Callback callback){
                stopImageGenServerThen(callback);
            }
            @Override public void startLocal(ImageServerModeCoordinator.Callback callback){
                startLocalImageGenForMode(callback);
            }
            @Override public void startRemote(ImageServerModeCoordinator.Callback callback){
                RemotePcServerControl control=remotePcServerControl;
                if(control==null){callback.onFailure("집 PC 원격 서버 기능은 후속 작업에서 연결됩니다.");return;}
                try{control.start(callback);}catch(Throwable error){callback.onFailure(msg(error));}
            }
            @Override public void persistMode(ImageServerModeCoordinator.Mode mode){
                String value=mode==ImageServerModeCoordinator.Mode.LOCAL_IMAGE_GENERATION?IMAGE_MODE_GENERATION
                        :mode==ImageServerModeCoordinator.Mode.REMOTE_PC?IMAGE_MODE_REMOTE_PC:IMAGE_MODE_PACKS_ONLY;
                getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_IMAGE_MODE,value).apply();
            }
            @Override public void onFinished(ImageServerModeCoordinator.Mode mode,String error){
                runOnUiThread(()->{
                    imageModeTransitionInProgress=false;
                    if(error!=null&&!error.isEmpty()){
                        imageGenSessionMessage="이미지 서버 전환 실패: "+error;
                        Toast.makeText(MainActivity.this,imageGenSessionMessage,Toast.LENGTH_LONG).show();
                    }else if(mode==ImageServerModeCoordinator.Mode.IMAGE_PACKS_ONLY){
                        imageGenSessionMessage="이미지팩 전용 모드 · 모든 등록 서버의 중지 요청을 완료했습니다.";
                    }else if(mode==ImageServerModeCoordinator.Mode.LOCAL_IMAGE_GENERATION){
                        imageGenSessionMessage="NovelAI 이미지 생성 서버가 준비되었습니다.";
                    }else if(mode==ImageServerModeCoordinator.Mode.REMOTE_PC){
                        imageGenSessionMessage="집 PC 서버 모드로 전환했습니다.";
                    }
                    refreshImageGenStatus();
                    renderImageModePanel();
                });
            }
        });
    }

    private void stopImageGenServerThen(ImageServerModeCoordinator.Callback callback){
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        if(!state.isReady()&&!state.isAvailable()&&!state.isStarting()&&!manualImageGenPreparing&&!imageGenCopying){
            callback.onSuccess();
            return;
        }
        stopImageGenServer();
        waitForImageGenStopped(callback,0);
    }

    private void waitForImageGenStopped(ImageServerModeCoordinator.Callback callback,int attempt){
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        boolean active=state.isReady()||state.isAvailable()||state.isStarting()||manualImageGenPreparing||imageGenCopying;
        if(!active){callback.onSuccess();return;}
        if(attempt>=60){
            callback.onFailure("휴대폰 이미지 생성 서버가 제한 시간 안에 종료되지 않았습니다. 서버 상태를 확인해 주세요.");
            return;
        }
        imageGenHandler.postDelayed(()->waitForImageGenStopped(callback,attempt+1),250);
    }

    private void startLocalImageGenForMode(ImageServerModeCoordinator.Callback callback){
        try{
            String token=NovelAiTokenStore.readToken(this);
            if(token==null||token.isEmpty()){
                callback.onFailure("NovelAI 토큰을 먼저 등록해야 합니다.");
                return;
            }
        }catch(Exception error){
            callback.onFailure("NovelAI 보안 저장소를 읽지 못했습니다: "+msg(error));
            return;
        }
        startManagedImageGenServer("novelai","");
        waitForImageGenReadyForMode(callback,0);
    }

    private void waitForImageGenReadyForMode(ImageServerModeCoordinator.Callback callback,int attempt){
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        if(state.isReady()){callback.onSuccess();return;}
        if(attempt>=360){
            stopImageGenServerThen(new ImageServerModeCoordinator.Callback(){
                @Override public void onSuccess(){callback.onFailure("NovelAI 이미지 생성 서버가 180초 안에 준비되지 않았습니다.");}
                @Override public void onFailure(String error){callback.onFailure("서버 시작 시간 초과 및 중지 실패: "+error);}
            });
            return;
        }
        if(!manualImageGenPreparing&&!imageGenCopying&&!state.isStarting()&&!state.isAvailable()){
            String detail=state.message==null||state.message.isEmpty()?imageGenSessionMessage:state.message;
            callback.onFailure(detail==null||detail.isEmpty()?"이미지 생성 서버 시작에 실패했습니다.":detail);
            return;
        }
        imageGenHandler.postDelayed(()->waitForImageGenReadyForMode(callback,attempt+1),500);
    }

    private void showLauncherInfoDialog(){
        new android.app.AlertDialog.Builder(this)
                .setTitle("런처 안내")
                .setMessage("게임 폴더는 읽기 권한으로 연결해 원본 파일을 직접 수정하지 않습니다. 등록한 게임은 각각 독립 세션으로 실행되며 브라우저 저장 데이터도 세션별로 분리됩니다.")
                .setPositiveButton("확인",null).show();
    }
    private void chooseFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        // A previously selected game folder is a subtree boundary, not the
        // starting point for registering a sibling game folder. Let the
        // document provider open its normal location so users can choose
        // another independent root instead of being trapped inside the
        // currently registered game's directory.
        JSONObject pickerDetails=new JSONObject();
        try{
            pickerDetails.put("registeredProfileCount",profiles.size());
            pickerDetails.put("initialUriProvided",false);
        }catch(Exception ignored){}
        DiagnosticsLogger.event(this,"INFO","launcher","folder_picker_opened",pickerDetails);
        startActivityForResult(i,PICK_TREE);
    }

    private void chooseModZip(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/x-zip-compressed","application/octet-stream"});i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i,PICK_MOD_ZIP);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==REQUEST_NAI_SETTINGS){
            boolean requestedStart=startImageServerAfterNaiSettings;
            startImageServerAfterNaiSettings=false;
            if(result==RESULT_OK){
                String token="";
                try{ token=NovelAiTokenStore.readToken(this); }catch(Exception error){
                    imageGenSessionMessage="NovelAI 보안 저장소를 읽지 못했습니다: "+msg(error);
                }
                if(token.isEmpty()) switchToImagePacksOnly();
                else if(requestedStart||IMAGE_MODE_GENERATION.equals(currentImageMode())) switchToImageGenerationMode();
                else renderImageModePanel();
            }else if(requestedStart){
                imageGenSessionMessage="NovelAI 설정이 완료되지 않아 이미지팩 전용 모드를 유지합니다.";
                renderImageModePanel();
            }
            return;
        }
        String authNonce=pendingGoogleAuthRequestNonces.remove(req);
        if(authNonce!=null){
            String nonce=authNonce;
            if(!nonce.equals(pendingGoogleAuthNonce))return;
            pendingGoogleAuthNonce="";
            if(result!=RESULT_OK||data==null){
                storeGoogleAuthResult(nonce,null,"Google 계정 권한 승인이 취소되었습니다.");
                return;
            }
            try{
                AuthorizationResult authorizationResult=Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
                storeGoogleAuthResult(nonce,authorizationResult.getAccessToken(),null);
            }catch(ApiException error){
                storeGoogleAuthResult(nonce,null,"Google 권한 결과를 처리하지 못했습니다: "+msg(error));
            }catch(Throwable error){
                storeGoogleAuthResult(nonce,null,"Google 권한 처리 실패: "+msg(error));
            }
            return;
        }
        if(WebDownloadHandler.isRequestCode(req)){
            if(webDownloadHandler!=null)webDownloadHandler.handleActivityResult(req,result,data);
            return;
        }
        if(req==ImagePackDirectoryAccess.REQUEST_CODE){
            if(imagePackDirectoryAccess!=null)imagePackDirectoryAccess.handleActivityResult(result,data);
            return;
        }
        if(WebFileChooser.isRequestCode(req)){
            if(webFileChooser!=null)webFileChooser.handleActivityResult(req,result,data);
            return;
        }
        if(req==PICK_TREE){
            if(result!=RESULT_OK||data==null||data.getData()==null){
                DiagnosticsLogger.event(this,"WARN","launcher","folder_picker_cancelled",null);
                return;
            }
            Uri picked=data.getData();int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try{
                getContentResolver().takePersistableUriPermission(picked,flags);
                DiagnosticsLogger.event(this,"INFO","launcher","folder_permission_persisted",null);
                String value=picked.toString();GameProfile profile=findProfileByUri(value);
                if(profile==null){
                    String name=new SafTree(picked).rootName();
                    profile=new GameProfile(UUID.randomUUID().toString().replace("-",""),value,name);
                    profiles.add(profile);
                }
                activeProfileId=profile.id;treeUri=picked;tree=new SafTree(picked);saveProfiles();
                refreshStatus();renderProfiles();renderZipMods();
                DiagnosticsLogger.event(this,"INFO","launcher","game_folder_registered",null);
                Toast.makeText(this,"게임 폴더를 등록했습니다. 목록에서 실행할 수 있습니다.",Toast.LENGTH_LONG).show();
            }catch(Exception e){DiagnosticsLogger.error(this,"launcher","folder_permission_failed",e);status("폴더 권한 저장 실패: "+msg(e));}
            return;
        }
        if(req==PICK_MOD_ZIP){
            if(result!=RESULT_OK||data==null)return;
            List<Uri> selected=collectSelectedUris(data);
            if(!selected.isEmpty())installModZips(selected);
        }
    }

    private List<Uri> collectSelectedUris(Intent data){
        List<Uri> selected=new ArrayList<>();
        ClipData clip=data.getClipData();
        if(clip!=null)for(int i=0;i<clip.getItemCount();i++){
            Uri uri=clip.getItemAt(i).getUri();
            if(uri!=null&&!selected.contains(uri))selected.add(uri);
        }
        Uri single=data.getData();
        if(single!=null&&!selected.contains(single))selected.add(single);
        return selected;
    }

    private String displayName(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())return c.getString(0);
        }catch(Exception ignored){}
        return "mod.zip";
    }

    private String installModZip(Uri uri)throws Exception{
        File staged=zipMods.temporaryFile(UUID.randomUUID().toString());
        try{
            String name=displayName(uri);
            if(name==null||!name.toLowerCase(Locale.ROOT).endsWith(".zip"))throw new IllegalArgumentException("확장자가 .zip인 모드 파일을 선택해 주세요.");
            try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(staged)){
                if(in==null)throw new IllegalStateException("선택한 ZIP 파일을 열 수 없습니다.");
                byte[] buffer=new byte[32768];long total=0;int n;
                while((n=in.read(buffer))!=-1){total+=n;if(total>512L*1024L*1024L)throw new IllegalArgumentException("ZIP은 최대 512MB까지만 설치할 수 있습니다.");out.write(buffer,0,n);}
                out.flush();
            }
            ZipModStore.ModInfo info=ZipModStore.inspect(staged);
            zipMods.install(staged);
            return info.id;
        }finally{if(staged.exists())staged.delete();}
    }

    private void installModZips(List<Uri> sources){
        status("ZIP 모드를 앱 내부 저장소에 설치하고 있습니다...");
        new Thread(()->{
            List<String> installed=new ArrayList<>(),failed=new ArrayList<>();
            for(Uri uri:sources)try{installed.add(installModZip(uri));}catch(Exception e){failed.add(displayName(uri)+": "+msg(e));}
            runOnUiThread(()->{
                if(!installed.isEmpty()){
                    bumpZipRevision();renderZipMods();refreshStatus();
                    if(web!=null){loadedZipRevision=getZipRevision();web.reload();}
                }else refreshStatus();
                String report="ZIP 설치 "+installed.size()+"개 완료"+(failed.isEmpty()?"":" · 실패 "+failed.size()+"개: "+failed.get(0));
                Toast.makeText(this,report,Toast.LENGTH_LONG).show();
            });
        },"wml-zip-installer").start();
    }

    private long getZipRevision(){return getSharedPreferences(PREFS,MODE_PRIVATE).getLong(KEY_ZIP_REV,0);}
    private void bumpZipRevision(){getSharedPreferences(PREFS,MODE_PRIVATE).edit().putLong(KEY_ZIP_REV,getZipRevision()+1).apply();}

    private void loadProfiles(){
        profiles.clear();
        String raw=getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_PROFILES,null);
        if(raw!=null)try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject p=a.optJSONObject(i);if(p==null)continue;
                String id=p.optString("id",""),uri=p.optString("uri",""),label=p.optString("label","Wayward");
                if(id.matches("[a-f0-9]{32}")&&!uri.isEmpty())profiles.add(new GameProfile(id,uri,label));
            }
        }catch(Exception ignored){}
        if(profiles.isEmpty()){
            String legacy=getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_TREE,null);
            if(legacy!=null)try{
                Uri u=Uri.parse(legacy);profiles.add(new GameProfile(UUID.randomUUID().toString().replace("-",""),legacy,new SafTree(u).rootName()));saveProfiles();
            }catch(Exception ignored){}
        }
    }

    private void saveProfiles(){
        JSONArray a=new JSONArray();
        try{for(GameProfile p:profiles){JSONObject o=new JSONObject();o.put("id",p.id);o.put("uri",p.uri);o.put("label",p.label);a.put(o);}}
        catch(Exception ignored){}
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_PROFILES,a.toString()).remove(KEY_TREE).apply();
    }

    private GameProfile findProfile(String id){for(GameProfile p:profiles)if(p.id.equals(id))return p;return null;}
    private GameProfile findProfileByUri(String uri){for(GameProfile p:profiles)if(p.uri.equals(uri))return p;return null;}
    private String sessionProfileId(Intent intent){
        Uri u=intent==null?null:intent.getData();
        if(u==null||!"wayward".equals(u.getScheme())||!"session".equals(u.getHost()))return null;
        String id=u.getLastPathSegment();return id!=null&&id.matches("[a-f0-9]{32}")?id:null;
    }
    private String sessionDomain(String id){
        return "localhost";
    }
    private int sessionPort(String id){
        return 10000 + Math.floorMod((id == null ? "default" : id).hashCode(), 50000);
    }
    private String sessionOrigin(String id){
        return "https://" + sessionDomain(id) + ":" + sessionPort(id);
    }

    private void launchProfileSession(String id){
        String requestId=UUID.randomUUID().toString();
        DiagnosticsLogger.event(this,"INFO","game-session","game_launch_requested",
                gameLifecycleDetails(id,requestId,"profile_button"));
        if(id!=null&&id.equals(activeProfileId)&&!isFinishing()){
            activeGameLaunchRequestId=requestId;
            if(web!=null){
                showGameSession("same_activity_same_profile");
                DiagnosticsLogger.event(this,"INFO","game-session","game_launch_reused_current_activity",
                        gameLifecycleDetails(id,requestId,"same_activity_same_profile"));
            }else{
                openProfileSession(id);
            }
            return;
        }

        MainActivity existing=findSessionActivity(id);
        Intent intent=new Intent(this,GameSessionActivity.class);
        intent.setData(Uri.parse("wayward://session/"+Uri.encode(id)));
        intent.putExtra(EXTRA_GAME_LAUNCH_REQUEST_ID,requestId);
        // Each profile has a distinct wayward://session/{id} base-intent URI.
        // NEW_DOCUMENT makes Android match that URI against document-task roots,
        // so a relaunch targets the correct profile Activity instead of the most
        // recent MainActivity instance in another game's task.
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
        if(existing!=null&&existing!=this){
            DiagnosticsLogger.event(this,"INFO","game-session","game_launch_existing_document_task",
                    gameLifecycleDetails(id,requestId,"existing_profile_document_task"));
        }else{
            DiagnosticsLogger.event(this,"INFO","game-session","game_launch_new_document_task",
                    gameLifecycleDetails(id,requestId,"new_profile_document_task"));
        }
        startActivity(intent);
    }

    private static MainActivity findSessionActivity(String id){
        if(id==null||!id.matches("[a-f0-9]{32}"))return null;
        WeakReference<MainActivity> reference=SESSION_ACTIVITIES.get(id);
        MainActivity activity=reference==null?null:reference.get();
        if(activity==null||activity.isFinishing()||activity.isDestroyed()
                ||!id.equals(activity.activeProfileId)||activity.web==null||activity.tree==null){
            if(reference!=null)SESSION_ACTIVITIES.remove(id,reference);
            return null;
        }
        return activity;
    }

    private JSONObject gameLifecycleDetails(String sessionId,String requestId,String reason){
        JSONObject details=new JSONObject();
        try{
            details.put("activityInstanceId",activityInstanceId);
            details.put("taskId",getTaskId());
            details.put("sessionId",sessionId==null?"":sessionId);
            details.put("launchRequestId",requestId==null?"":requestId);
            details.put("webViewInstanceId",webViewInstanceId);
            details.put("webViewGeneration",webViewGeneration);
            details.put("webViewCreated",web!=null);
            details.put("webViewVisible",web!=null&&web.getVisibility()==View.VISIBLE);
            details.put("homeVisible",home!=null&&home.getVisibility()==View.VISIBLE);
            details.put("gamePageLoaded",gamePageLoaded);
            details.put("reason",reason==null?"":reason);
        }catch(Exception ignored){}
        return details;
    }

    private void logGameLifecycle(String level,String event,String sessionId,String requestId,String reason){
        DiagnosticsLogger.event(this,level,"game-session",event,
                gameLifecycleDetails(sessionId,requestId,reason));
    }

    private void logGamePageLifecycle(String event,String url,String reason){
        JSONObject details=gameLifecycleDetails(activeProfileId,activeGameLaunchRequestId,reason);
        JSONObject page=ImagePackDiagnostics.pageDetails(url,true);
        try{
            details.put("pageOrigin",page.optString("origin"));
            details.put("pagePath",page.optString("pagePath"));
            details.put("mainFrame",page.optBoolean("mainFrame",true));
        }catch(Exception ignored){}
        DiagnosticsLogger.event(this,"INFO","game-session",event,details);
    }

    private boolean isCurrentGamePage(String url){
        if(activeProfileId==null||activeProfileId.isEmpty()||url==null)return false;
        try{
            Uri parsed=Uri.parse(url);
            return "https".equalsIgnoreCase(parsed.getScheme())
                    &&"localhost".equalsIgnoreCase(parsed.getHost())
                    &&parsed.getPort()==sessionPort(activeProfileId)
                    &&parsed.getPath()!=null&&parsed.getPath().startsWith("/game/");
        }catch(Exception ignored){return false;}
    }

    private void showGameSession(String reason){
        if(web==null)return;
        if(home!=null)home.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        web.bringToFront();
        registerSessionActivity();
        logGameLifecycle("INFO","game_session_brought_to_front",activeProfileId,
                activeGameLaunchRequestId,reason);
        if(gamePageLoaded){
            logGameLifecycle("INFO","game_session_visible",activeProfileId,
                    activeGameLaunchRequestId,"loaded_page_reused");
        }
    }

    private void openProfileSession(String id){
        if(activeGameLaunchRequestId==null||activeGameLaunchRequestId.isEmpty()){
            activeGameLaunchRequestId=UUID.randomUUID().toString();
        }
        logGameLifecycle("INFO","game_session_open_started",id,activeGameLaunchRequestId,"openProfileSession");
        GameProfile p=findProfile(id);
        if(p==null){
            logGameLifecycle("ERROR","game_page_error",id,activeGameLaunchRequestId,"profile_not_found");
            status("등록된 게임 폴더를 찾지 못했습니다. 홈에서 다시 등록해 주세요.");
            return;
        }
        try{
            if(web!=null)destroyWeb();
            activeProfileId=p.id;treeUri=Uri.parse(p.uri);tree=new SafTree(treeUri);
            gamePageLoaded=false;
            gamePageLoadFailed=false;
            imagePackDiagnosticSessionId=ImagePackDiagnostics.newSessionId();
            ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "", "game_session_start",
                    "info", ImagePackDiagnostics.pageDetails(sessionOrigin(activeProfileId), true));
            String file=gameFile();
            if(file==null){
                DiagnosticsLogger.event(this,"ERROR","game-session","game_page_error",
                        gameLifecycleDetails(id,activeGameLaunchRequestId,"game_html_not_found"));
                status("선택한 폴더에서 Wayward HTML을 찾지 못했습니다: "+p.label);
                return;
            }
            setTitle("Wayward · "+p.label);
            RUNNING_SESSIONS.add(p.id);
            if(home!=null)home.setVisibility(View.GONE);
            loadedZipRevision=getZipRevision();
            createWeb();web.setVisibility(View.VISIBLE);
            registerSessionActivity();
            String gameUrl=sessionOrigin(activeProfileId)+"/game/"+Uri.encode(file)+"?launcher="+System.currentTimeMillis();
            logGameLifecycle("INFO","game_webview_load_requested",p.id,activeGameLaunchRequestId,"loadUrl");
            web.loadUrl(gameUrl);
        }catch(Exception e){
            DiagnosticsLogger.error(this,"game-session","game_session_open_failed",e);
            logGameLifecycle("ERROR","game_page_error",id,activeGameLaunchRequestId,"open_profile_exception");
            status("게임 실행 실패: "+msg(e));
        }
    }

    private void removeProfile(String id){
        if(RUNNING_SESSIONS.contains(id)){
            Toast.makeText(this,"실행 중인 세션은 먼저 게임 화면에서 나간 뒤 삭제해 주세요.",Toast.LENGTH_LONG).show();return;
        }
        for(int i=profiles.size()-1;i>=0;i--)if(profiles.get(i).id.equals(id))profiles.remove(i);
        saveProfiles();renderProfiles();refreshStatus();
    }

    private void renderProfiles(){
        if(profileList==null)return;
        profileList.removeAllViews();
        if(profileSummary!=null)profileSummary.setText(profiles.size()+"개 등록");
        if(profiles.isEmpty()){
            LinearLayout empty=uiCard();
            empty.addView(uiText("등록된 게임이 없습니다.",13,Color.rgb(44,48,52),true));
            LinearLayout.LayoutParams hintParams=new LinearLayout.LayoutParams(-1,-2);hintParams.topMargin=dp(4);
            empty.addView(uiText("상단의 폴더 추가를 눌러 Wayward 또는 Faith 폴더를 선택하세요.",11,Color.rgb(112,119,126),false),hintParams);
            profileList.addView(empty);return;
        }
        for(GameProfile p:profiles){
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setPadding(dp(11),dp(7),dp(7),dp(7));
            card.setBackground(uiShape(Color.WHITE,Color.rgb(229,232,235),14));
            LinearLayout.LayoutParams cardParams=new LinearLayout.LayoutParams(-1,-2);cardParams.bottomMargin=dp(6);
            profileList.addView(card,cardParams);
            LinearLayout identity=new LinearLayout(this);identity.setOrientation(LinearLayout.VERTICAL);
            TextView name=uiText(p.label,14,Color.rgb(30,34,38),true);name.setMaxLines(1);
            identity.addView(name);
            TextView meta=uiText(p.id.equals(activeProfileId)?"현재 선택된 게임":"등록된 게임 폴더",10,Color.rgb(124,131,138),false);
            LinearLayout.LayoutParams metaParams=new LinearLayout.LayoutParams(-1,-2);metaParams.topMargin=dp(3);
            identity.addView(meta,metaParams);
            card.addView(identity,new LinearLayout.LayoutParams(0,dp(42),1f));
            Button start=compactButton("실행",true,()->launchProfileSession(p.id));
            card.addView(start,new LinearLayout.LayoutParams(dp(66),dp(38)));
            Button more=compactButton("⋯",false,()->showProfileActions(p));
            LinearLayout.LayoutParams moreParams=new LinearLayout.LayoutParams(dp(40),dp(38));moreParams.leftMargin=dp(5);
            card.addView(more,moreParams);
        }
    }

    private void showProfileActions(GameProfile profile){
        new android.app.AlertDialog.Builder(this).setTitle(profile.label)
                .setItems(new String[]{"게임 실행","폴더 등록 해제"},(dialog,which)->{
                    if(which==0)launchProfileSession(profile.id);
                    else new android.app.AlertDialog.Builder(this).setTitle("게임 폴더 등록 해제")
                            .setMessage(profile.label+" 폴더를 런처 목록에서 제거할까요? 게임 원본 파일은 삭제되지 않습니다.")
                            .setNegativeButton("취소",null)
                            .setPositiveButton("등록 해제",(confirm,button)->removeProfile(profile.id)).show();
                }).setNegativeButton("닫기",null).show();
    }

    private void renderZipMods(){
        if(zipMods==null)return;
        List<String> ids=zipMods.listModIds();
        if(zipSummary!=null)zipSummary.setText(ids.size()+"개 설치됨");
        if(zipModList==null)return;
        zipModList.removeAllViews();
        for(String id:ids){
            TextView label=uiText(id,12,Color.rgb(57,62,67),false);
            zipModList.addView(label,new LinearLayout.LayoutParams(-1,dp(34)));
        }
    }

    private void showZipManager(){
        List<String> ids=zipMods==null?new ArrayList<>():zipMods.listModIds();
        android.app.AlertDialog.Builder dialog=new android.app.AlertDialog.Builder(this).setTitle("ZIP 모드 관리");
        if(ids.isEmpty()){
            dialog.setMessage("설치된 ZIP 모드가 없습니다.");
        }else{
            dialog.setItems(ids.toArray(new String[0]),(window,which)->showZipModActions(ids.get(which)));
        }
        dialog.setPositiveButton("ZIP 설치",(window,which)->chooseModZip());
        dialog.setNegativeButton("닫기",null);dialog.show();
    }

    private void showZipModActions(String id){
        new android.app.AlertDialog.Builder(this).setTitle(id)
                .setMessage("이 ZIP 모드를 앱 내부 저장소에서 제거할까요?")
                .setNegativeButton("취소",null)
                .setPositiveButton("제거",(dialog,which)->{
                    if(zipMods!=null&&zipMods.uninstall(id)){
                        bumpZipRevision();renderZipMods();refreshStatus();
                        if(web!=null){loadedZipRevision=getZipRevision();web.reload();}
                    }else Toast.makeText(this,"ZIP 모드를 제거하지 못했습니다.",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private String gameFile(){
        if(tree==null)return null;
        if(tree.exists(KO))return KO;if(tree.exists(EN))return EN;if(tree.exists("index.html"))return "index.html";
        try{
            List<String> names=tree.rootHtmlFiles();Collections.sort(names,String.CASE_INSENSITIVE_ORDER);
            for(String name:names)if(name.toLowerCase(Locale.ROOT).startsWith("wayward_faith"))return name;
            for(String name:names)if(name.toLowerCase(Locale.ROOT).startsWith("wayward"))return name;
            return names.size()==1?names.get(0):null;
        }catch(Exception ignored){return null;}
    }
    private List<String> allModIds(){
        Set<String> ids=new TreeSet<>();
        if(tree!=null)try{ids.addAll(tree.listModIds());}catch(Exception ignored){}
        if(zipMods!=null)ids.addAll(zipMods.listModIds());
        return new ArrayList<>(ids);
    }
    private void refreshStatus(){
        if(tree==null){
            status("준비 완료  ·  게임 "+profiles.size()+"개 등록됨");
            if(folderText!=null)folderText.setText("게임 폴더를 등록하면 여기에서 상태를 확인할 수 있습니다.");
            return;
        }
        try{
            String f=gameFile();
            status(f==null?"선택한 폴더에서 게임 HTML을 찾지 못했습니다.":"게임 폴더 확인 완료  ·  WML 모드 "+allModIds().size()+"개");
            if(folderText!=null)folderText.setText(tree.rootName()+"  ·  "+(f==null?"실행 파일 없음":f));
        }catch(Exception e){
            status("폴더를 읽을 수 없습니다. "+msg(e));
        }
    }
    private void refreshGame(){if(web!=null&&web.getVisibility()==View.VISIBLE){if(tree!=null)tree.invalidateDirectoryIndex();web.clearCache(true);web.reload();Toast.makeText(this,"게임 파일을 다시 읽습니다.",Toast.LENGTH_SHORT).show();}else refreshStatus();}

    private void createWeb(){
        String domain=sessionDomain(activeProfileId);
        String origin=sessionOrigin(activeProfileId);
        int originPort=sessionPort(activeProfileId);
        web=new WebView(this);
        webViewGeneration++;
        webViewInstanceId=UUID.randomUUID().toString();
        gamePageLoaded=false;
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setUseWideViewPort(true);s.setLoadWithOverviewMode(true);s.setTextZoom(100);s.setSupportZoom(true);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setCacheMode(WebSettings.LOAD_DEFAULT);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);imagePackDirectoryAccess=new ImagePackDirectoryAccess(this,web,activeProfileId,imagePackDiagnosticSessionId);
        ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "", "webview_created", "info",
                new JSONObject());
        logGameLifecycle("INFO","game_webview_created",activeProfileId,activeGameLaunchRequestId,
                "generation_"+webViewGeneration);
        webDownloadHandler=new WebDownloadHandler(this,web);
        web.addJavascriptInterface(new HostBridge(),"WMLHost");
        ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "", "javascript_interface_registered",
                "info", null);
        installGoogleAuthBridgeScript(origin);
        installWaywardDownloadBridge(origin);
        installImageGenDocumentStartScript(origin);
        FolderHandler folderHandler=new FolderHandler(tree,getAssets(),zipMods,origin);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().setDomain(domain+":"+originPort).addPathHandler("/game/",folderHandler).build();
        final java.util.concurrent.atomic.AtomicInteger imageDiagnostics=new java.util.concurrent.atomic.AtomicInteger();
        final java.util.LinkedHashMap<String,Integer> imageHttpErrorCounts=new java.util.LinkedHashMap<>();
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon){
                DiagnosticsLogger.event(MainActivity.this,"INFO","webview","page_started",null);
                ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, "",
                        "webview_page_started", "info", ImagePackDiagnostics.pageDetails(url, true));
                if(view==web&&isCurrentGamePage(url)){
                    gamePageLoaded=false;
                    gamePageLoadFailed=false;
                    logGamePageLifecycle("game_page_started",url,"main_frame_start");
                }
                super.onPageStarted(view,url,favicon);
            }
            @Override public void onPageFinished(WebView view,String url){
                if(!waywardDownloadBridgeDocumentStartRegistered && waywardDownloadBridgeScript!=null
                        &&ImagePackFolderPickerScript.isSameOrigin(url,waywardDownloadBridgeOrigin)){
                    view.evaluateJavascript(waywardDownloadBridgeScript,null);
                }
                DiagnosticsLogger.event(MainActivity.this,"INFO","webview","page_finished",null);
                ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, "",
                        "webview_page_finished", "info", ImagePackDiagnostics.pageDetails(url, true));
                if(view==web&&isCurrentGamePage(url)){
                    if(!gamePageLoadFailed){
                        gamePageLoaded=true;
                        logGamePageLifecycle("game_page_finished",url,"main_frame_finished");
                        if(web.getVisibility()==View.VISIBLE){
                            logGamePageLifecycle("game_session_visible",url,"main_frame_page_finished");
                        }
                    }else{
                        gamePageLoaded=false;
                    }
                }
                if(imagePackFolderPickerScript!=null
                        &&ImagePackFolderPickerScript.isSameOrigin(url,imagePackFolderPickerOrigin)){
                    ImagePackFolderPickerScript.installAfterPageFinished(
                            view,url,imagePackFolderPickerOrigin,imagePackFolderPickerScript,installed->{
                                JSONObject details = new JSONObject();
                                try {
                                    details.put("installed", installed);
                                    details.put("origin", ImagePackDiagnostics.pageDetails(url, true).optString("origin"));
                                } catch (Exception ignored) {}
                                ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, "",
                                        installed ? "folder_picker_runtime_install_verified" : "folder_picker_runtime_install_failed",
                                        installed ? "info" : "error", details);
                                if(!installed)DiagnosticsLogger.event(MainActivity.this,"ERROR","image-pack",
                                        "folder_picker_runtime_install_failed",null);
                            });
                } else {
                    ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, "",
                            "folder_picker_page_origin_skipped", "warn", ImagePackDiagnostics.pageDetails(url, true));
                }
                super.onPageFinished(view,url);
            }
            @Override public void onReceivedError(WebView view,WebResourceRequest request,android.webkit.WebResourceError error){
                if(request!=null&&!request.isForMainFrame()){
                    Uri failedUri=request.getUrl();
                    String failedPath=failedUri==null?null:failedUri.getPath();
                    if(isImageResourcePath(failedPath)){
                        JSONObject pipeline=new JSONObject();
                        try{
                            pipeline.put("networkErrorCode",error==null?0:error.getErrorCode());
                            pipeline.put("srcKind",failedUri!=null&&domain.equalsIgnoreCase(failedUri.getHost())?"game_asset":"external");
                            ImagePipelineDiagnostics.addSanitizedUrl(pipeline,failedUri==null?null:failedUri.toString());
                        }catch(Exception ignored){}
                        ImagePipelineDiagnostics.record(MainActivity.this,"webview_image_network_error",pipeline);
                    }
                }
                if(request!=null&&request.isForMainFrame()){
                    JSONObject details=new JSONObject();
                    try{details.put("code",error==null?0:error.getErrorCode());}catch(Exception ignored){}
                    DiagnosticsLogger.event(MainActivity.this,"ERROR","webview","main_frame_load_error",details);
                    ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, "",
                            "webview_main_frame_load_failed", "error",
                            ImagePackDiagnostics.pageDetails(request.getUrl().toString(), true));
                    if(isCurrentGamePage(request.getUrl().toString())){
                        gamePageLoaded=false;
                        gamePageLoadFailed=true;
                        logGamePageLifecycle("game_page_error",request.getUrl().toString(),
                                "main_frame_network_error_"+(error==null?0:error.getErrorCode()));
                    }
                }
                super.onReceivedError(view,request,error);
            }
            @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,WebResourceResponse response){
                if(request!=null&&response!=null&&response.getStatusCode()>=400){
                    Uri failedUri=request.getUrl();
                    String failedPath=failedUri==null?null:failedUri.getPath();
                    boolean imageResource=isImageResourcePath(failedPath);
                    boolean handledByLocalImageLogger=failedPath!=null&&(
                            (domain.equalsIgnoreCase(failedUri.getHost())&&FolderHandler.isImageRequestPath(failedPath))
                            ||("art.sintention.com".equalsIgnoreCase(failedUri.getHost())
                                &&FolderHandler.isLocalOnlyCharacterImagePath(failedPath)));
                    if(imageResource){
                        String safePath=ImagePipelineDiagnostics.sanitizePath(failedPath);
                        String sampleKey=(failedUri==null?"":String.valueOf(failedUri.getHost()))+"|"+safePath;
                        int repeatCount;
                        synchronized(imageHttpErrorCounts){
                            Integer previous=imageHttpErrorCounts.get(sampleKey);
                            repeatCount=previous==null?1:previous+1;
                            if(previous==null&&imageHttpErrorCounts.size()>=256){
                                String oldest=imageHttpErrorCounts.keySet().iterator().next();
                                imageHttpErrorCounts.remove(oldest);
                            }
                            imageHttpErrorCounts.put(sampleKey,repeatCount);
                        }
                        if(repeatCount<=2||repeatCount%10==0){
                            JSONObject pipeline=new JSONObject();
                            try{
                                pipeline.put("responseStatus",response.getStatusCode());
                                pipeline.put("srcKind",domain.equalsIgnoreCase(failedUri.getHost())?"game_asset":"external");
                                pipeline.put("repeatCount",repeatCount);
                                ImagePipelineDiagnostics.addSanitizedUrl(pipeline,failedUri==null?null:failedUri.toString());
                            }catch(Exception ignored){}
                            ImagePipelineDiagnostics.record(MainActivity.this,"webview_image_http_error",pipeline);
                        }
                    }
                    if(request.isForMainFrame()&&isCurrentGamePage(request.getUrl().toString())){
                        gamePageLoaded=false;
                        gamePageLoadFailed=true;
                        logGamePageLifecycle("game_page_error",request.getUrl().toString(),
                                "main_frame_http_"+response.getStatusCode());
                    }
                    if(imageResource&&!handledByLocalImageLogger&&imageDiagnostics.getAndIncrement()<16){
                        JSONObject details=new JSONObject();
                        try{
                            details.put("host",failedUri==null?"":failedUri.getHost());
                            details.put("path",ImagePipelineDiagnostics.sanitizePath(failedPath));
                            details.put("status",response.getStatusCode());
                            details.put("mainFrame",request.isForMainFrame());
                        }catch(Exception ignored){}
                        DiagnosticsLogger.event(MainActivity.this,"WARN","webview","image_http_error",details);
                    }else if(request.isForMainFrame()){
                        JSONObject details=new JSONObject();
                        try{details.put("status",response.getStatusCode());}catch(Exception ignored){}
                        DiagnosticsLogger.event(MainActivity.this,"WARN","webview","main_frame_http_error",details);
                    }
                }
                super.onReceivedHttpError(view,request,response);
            }
            @Override public boolean onRenderProcessGone(WebView view,android.webkit.RenderProcessGoneDetail detail){
                JSONObject details=new JSONObject();
                try{details.put("didCrash",detail!=null&&detail.didCrash());details.put("priority",detail==null?-1:detail.rendererPriorityAtExit());}catch(Exception ignored){}
                DiagnosticsLogger.event(MainActivity.this,"ERROR","webview","renderer_process_gone",details);
                if(view==web){
                    gamePageLoaded=false;
                    gamePageLoadFailed=true;
                    logGameLifecycle("ERROR","game_page_error",activeProfileId,activeGameLaunchRequestId,
                            "webview_renderer_process_gone");
                }
                return super.onRenderProcessGone(view,detail);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
                Uri u=r.getUrl();
                WebResourceResponse local=loader.shouldInterceptRequest(u);
                if(local!=null)return local;
                if(domain.equalsIgnoreCase(u.getHost())&&u.getPort()==originPort){
                    String path=u.getPath();
                    if(FolderHandler.isGameRequestPath(path)){
                        if(r.isForMainFrame()){
                            JSONObject details=new JSONObject();
                            try{details.put("authority",u.getAuthority());details.put("path",path);}catch(Exception ignored){}
                            DiagnosticsLogger.event(MainActivity.this,"WARN","webview","asset_loader_direct_fallback",details);
                        }
                        return folderHandler.serveGamePath(path.substring(6));
                    }
                    if(path != null && path.startsWith("/images/__wayward_generated__/")) {
                        if(IMAGE_MODE_REMOTE_PC.equals(currentImageMode()))
                            return RemoteGameResourceBridge.serve(MainActivity.this,u.getEncodedPath(),r.getRequestHeaders(),imageDiagnostics);
                        return serveGeneratedImageRequest(path, imageDiagnostics);
                    }
                    if(FolderHandler.isImageRequestPath(path))return serveImageRequestByMode(folderHandler,path,u.getEncodedPath(),r.getRequestHeaders(),imageDiagnostics);
                }
                String requestedPath=u.getPath();
                if(FolderHandler.isImageRequestPath(requestedPath)){
                    // Every image URL is local-pack-only while OFF and generated-cache-only while ON.
                    // No host (including the original art CDN) is allowed to become a fallback.
                    return serveImageRequestByMode(folderHandler,requestedPath,u.getEncodedPath(),r.getRequestHeaders(),imageDiagnostics);
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                Uri u=r.getUrl();if(domain.equalsIgnoreCase(u.getHost())&&u.getPort()==originPort)return false;
                String p=u.getScheme();if("https".equalsIgnoreCase(p)||"http".equalsIgnoreCase(p)||"mailto".equalsIgnoreCase(p)){try{startActivity(new Intent(Intent.ACTION_VIEW,u));return true;}catch(Exception ignored){return false;}}return true;
            }
        });
        webFileChooser=new WebFileChooser(this,imagePackDiagnosticSessionId);web.setWebChromeClient(webFileChooser);root.addView(web,new FrameLayout.LayoutParams(-1,-1));web.setVisibility(View.GONE);
    }


    private void beginGoogleDriveAuth(String nonce){
        beginGoogleDriveAuth(nonce,false);
    }

    private synchronized int reserveGoogleAuthRequestCode(String nonce){
        // Never reuse a request code during this Activity lifetime. A cancelled
        // PendingIntent may still deliver its ActivityResult after a later retry.
        if(nextGoogleAuthRequestCode>REQUEST_GOOGLE_AUTH_MAX){
            throw new IllegalStateException("Google 인증 요청 한도를 초과했습니다. 런처를 다시 시작해 주세요.");
        }
        int requestCode=nextGoogleAuthRequestCode++;
        pendingGoogleAuthRequestNonces.put(requestCode,nonce);
        return requestCode;
    }

    private void clearGoogleDriveAuthRequest(String nonce){
        if(nonce==null)return;
        if(nonce.equals(pendingGoogleAuthNonce))pendingGoogleAuthNonce="";
        for(Integer requestCode:pendingGoogleAuthRequestNonces.keySet()){
            if(nonce.equals(pendingGoogleAuthRequestNonces.get(requestCode))){
                pendingGoogleAuthRequestNonces.remove(requestCode,nonce);
            }
        }
        PENDING_GOOGLE_AUTH_RESULTS.remove(nonce);
    }

    private void beginGoogleDriveAuth(String nonce,boolean forceSelectAccount){
        if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return;
        if(!pendingGoogleAuthNonce.isEmpty()){
            storeGoogleAuthResult(nonce,null,"이미 다른 Google 권한 요청이 진행 중입니다.");
            return;
        }
        PENDING_GOOGLE_AUTH_RESULTS.remove(nonce);
        pendingGoogleAuthNonce=nonce;
        try{
            AuthorizationRequest.Builder requestBuilder=AuthorizationRequest.builder()
                    .setRequestedScopes(Collections.singletonList(
                            new Scope("https://www.googleapis.com/auth/drive.appdata")));
            if(forceSelectAccount){
                requestBuilder.setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT);
            }
            AuthorizationRequest request=requestBuilder.build();
            Identity.getAuthorizationClient(this).authorize(request)
                    .addOnSuccessListener(authorizationResult->{
                        if(!nonce.equals(pendingGoogleAuthNonce))return;
                        if(authorizationResult.hasResolution()){
                            try{
                                android.app.PendingIntent pending=authorizationResult.getPendingIntent();
                                if(pending==null)throw new IllegalStateException("Google 권한 확인 화면을 열 수 없습니다.");
                                int requestCode=reserveGoogleAuthRequestCode(nonce);
                                startIntentSenderForResult(pending.getIntentSender(),requestCode,null,0,0,0);
                            }catch(android.content.IntentSender.SendIntentException error){
                                clearGoogleDriveAuthRequest(nonce);
                                storeGoogleAuthResult(nonce,null,"Google 권한 화면을 시작하지 못했습니다: "+msg(error));
                            }catch(Throwable error){
                                clearGoogleDriveAuthRequest(nonce);
                                storeGoogleAuthResult(nonce,null,"Google 권한 요청 실패: "+msg(error));
                            }
                        }else{
                            clearGoogleDriveAuthRequest(nonce);
                            storeGoogleAuthResult(nonce,authorizationResult.getAccessToken(),null);
                        }
                    })
                    .addOnFailureListener(error->{
                        if(nonce.equals(pendingGoogleAuthNonce)){
                            clearGoogleDriveAuthRequest(nonce);
                            storeGoogleAuthResult(nonce,null,"Google Drive 권한 요청 실패: "+msg(error));
                        }
                    });
        }catch(Throwable error){
            clearGoogleDriveAuthRequest(nonce);
            storeGoogleAuthResult(nonce,null,"Google 인증 서비스를 사용할 수 없습니다: "+msg(error));
        }
    }

    private static void storeGoogleAuthResult(String nonce,String accessToken,String error){
        if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return;
        JSONObject payload=new JSONObject();
        try{
            payload.put("nonce",nonce);
            if(error==null&&accessToken!=null&&!accessToken.isEmpty()){
                payload.put("type","wayward-cloud-auth-success");
                payload.put("accessToken",accessToken);
                payload.put("expiresIn",3600);
            }else{
                payload.put("type","wayward-cloud-auth-error");
                payload.put("message",error==null?"Google에서 액세스 토큰을 반환하지 않았습니다.":error);
            }
            PENDING_GOOGLE_AUTH_RESULTS.put(nonce,payload.toString());
        }catch(Exception ignored){}
    }

    private static void storeGoogleRevokeResult(String nonce,boolean revoked,String error){
        if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return;
        JSONObject payload=new JSONObject();
        try{
            payload.put("type","wayward-cloud-revoke-result");
            payload.put("nonce",nonce);
            payload.put("revoked",revoked);
            if(error!=null&&!error.isEmpty())payload.put("error",error);
            PENDING_GOOGLE_AUTH_RESULTS.put(nonce,payload.toString());
        }catch(Exception ignored){}
    }

    private void installGoogleAuthBridgeScript(String gameOrigin){
        if(web==null||gameOrigin==null||gameOrigin.isEmpty())return;
        if(!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)){
            DiagnosticsLogger.event(this,"WARN","oauth","document_start_script_unavailable",null);
            return;
        }
        try(InputStream input=getAssets().open("wayward-google-auth-bridge.js");
            ByteArrayOutputStream output=new ByteArrayOutputStream()){
            byte[] buffer=new byte[4096];int count;
            while((count=input.read(buffer))!=-1)output.write(buffer,0,count);
            String script=new String(output.toByteArray(),StandardCharsets.UTF_8);
            WebViewCompat.addDocumentStartJavaScript(web,script,Collections.singleton(gameOrigin));
            DiagnosticsLogger.event(this,"INFO","oauth","native_google_auth_bridge_installed",null);
        }catch(Throwable error){
            DiagnosticsLogger.error(this,"oauth","native_google_auth_bridge_install_failed",error);
        }
    }

    private static boolean isImageResourcePath(String path){
        if(path==null)return false;
        String lower=path.toLowerCase(Locale.ROOT);
        return FolderHandler.isImageRequestPath(path)
                ||lower.endsWith(".png")||lower.endsWith(".jpg")||lower.endsWith(".jpeg")
                ||lower.endsWith(".webp")||lower.endsWith(".gif")||lower.endsWith(".avif")
                ||lower.endsWith(".svg");
    }

    private boolean imageGenerationRoutingActive(){
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        return state.isReady()||state.isAvailable()||state.isStarting();
    }

    private WebResourceResponse serveImageRequestByMode(FolderHandler handler,String path,
            String encodedPath,java.util.Map<String,String> requestHeaders,
            java.util.concurrent.atomic.AtomicInteger samples){
        if(IMAGE_MODE_REMOTE_PC.equals(currentImageMode())){
            return RemoteGameResourceBridge.serve(this,encodedPath,requestHeaders,samples);
        }
        if(imageGenerationRoutingActive()){
            return serveGeneratedImageRequest("/images/__wayward_generated__/"+path.substring(8),samples);
        }
        return serveImageRequest(handler,path,samples);
    }

    private WebResourceResponse serveImageRequest(FolderHandler handler,String path,
                                                       java.util.concurrent.atomic.AtomicInteger samples){
        long started=System.nanoTime();
        WebResourceResponse response=handler.serveImagePath(path.substring(8));
        long elapsedMs=(System.nanoTime()-started)/1_000_000L;
        int status=response==null?0:response.getStatusCode();
        if(response!=null&&(status>=400||elapsedMs>=350)&&samples.getAndIncrement()<16){
            JSONObject details=new JSONObject();
            try{
                details.put("path",ImagePipelineDiagnostics.sanitizePath(path));
                details.put("status",status);
                details.put("elapsedMs",elapsedMs);
            }catch(Exception ignored){}
            JSONObject pipeline=new JSONObject();
            try{
                pipeline.put("responseStatus",status);
                pipeline.put("elapsedMs",elapsedMs);
                pipeline.put("srcKind","game_asset");
                ImagePipelineDiagnostics.addSanitizedPath(pipeline,path);
            }catch(Exception ignored){}
            ImagePipelineDiagnostics.record(this,status>=400?"webview_image_resource_error":"webview_image_resource_slow",pipeline);
            DiagnosticsLogger.event(this,"WARN","webview","image_resource_slow_or_failed",details);
        }
        return response;
    }


    /**
     * Serves ImageGen's app-private cache under the HTTPS game origin.
     * The managed Bun server is HTTP loopback-only, so its /images URL cannot
     * be used directly by this HTTPS WebView (mixed content is disabled).
     */
    private WebResourceResponse serveGeneratedImageRequest(
            String requestPath, java.util.concurrent.atomic.AtomicInteger samples) {
        final String prefix = "/images/__wayward_generated__/";
        if (requestPath == null || !requestPath.startsWith(prefix)) {
            return generatedImageError(404, "Not Found", requestPath);
        }
        try {
            String relative = FolderHandler.normal(requestPath.substring(prefix.length()));
            if (relative == null) return generatedImageError(400, "Bad Request", requestPath);

            String mime = FolderHandler.mime(relative);
            if (!("image/png".equals(mime) || "image/jpeg".equals(mime)
                    || "image/webp".equals(mime) || "image/gif".equals(mime)
                    || "image/avif".equals(mime))) {
                return generatedImageError(415, "Unsupported Media Type", requestPath);
            }

            File root = new File(getFilesDir(), "imagegen/images").getCanonicalFile();
            File image = new File(root, relative).getCanonicalFile();
            String rootPrefix = root.getPath() + File.separator;
            if (!image.getPath().startsWith(rootPrefix)) {
                return generatedImageError(403, "Forbidden", requestPath);
            }
            if (!image.isFile()) return generatedImageError(404, "Not Found", requestPath);
            long length = image.length();
            if (length <= 0 || length > 25L * 1024L * 1024L) {
                return generatedImageError(413, "Content Too Large", requestPath);
            }

            java.util.HashMap<String, String> headers = new java.util.HashMap<>();
            headers.put("Cache-Control", "no-store");
            headers.put("X-Content-Type-Options", "nosniff");
            return new WebResourceResponse(mime, null, 200, "OK", headers, new java.io.FileInputStream(image));
        } catch (java.io.FileNotFoundException error) {
            return generatedImageError(404, "Not Found", requestPath);
        } catch (Exception error) {
            return generatedImageError(500, "Read Error", requestPath);
        }
    }

    private WebResourceResponse generatedImageError(int status, String reason, String requestPath) {
        try {
            JSONObject diagnostic = new JSONObject();
            diagnostic.put("srcKind", "generated_image");
            diagnostic.put("responseStatus", status);
            ImagePipelineDiagnostics.addSanitizedPath(diagnostic, requestPath);
            ImagePipelineDiagnostics.record(this, "webview_generated_image_resource_error", diagnostic);
        } catch (Exception ignored) {}
        byte[] body = "Generated image unavailable".getBytes(StandardCharsets.UTF_8);
        java.util.HashMap<String, String> headers = new java.util.HashMap<>();
        headers.put("Cache-Control", "no-store");
        headers.put("X-Content-Type-Options", "nosniff");
        return new WebResourceResponse("text/plain", "UTF-8", status, reason, headers,
                new ByteArrayInputStream(body));
    }

    private void installWaywardDownloadBridge(String origin) {
        waywardDownloadBridgeOrigin = origin;
        waywardDownloadBridgeDocumentStartRegistered = false;
        try (InputStream input = getAssets().open("wayward-download-bridge.js");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
                if (output.size() > 64 * 1024) throw new IllegalStateException("Download bridge script is too large.");
            }
            waywardDownloadBridgeScript = new String(output.toByteArray(), StandardCharsets.UTF_8);
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                        web, waywardDownloadBridgeScript, Collections.singleton(origin));
                waywardDownloadBridgeDocumentStartRegistered = true;
            }
            DiagnosticsLogger.event(this, "INFO", "webview", waywardDownloadBridgeDocumentStartRegistered
                    ? "blob_download_bridge_document_start_registered"
                    : "blob_download_bridge_page_start_fallback", null);
        } catch (Exception error) {
            waywardDownloadBridgeScript = null;
            DiagnosticsLogger.error(this, "webview", "blob_download_bridge_install_failed", error);
        }
    }

    private void installImageGenDocumentStartScript(String origin) {
        boolean documentStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        try {
            imagePackFolderPickerCapability = ImagePackFolderPickerScript.createCapability();
            imagePackFolderPickerScript = ImagePackFolderPickerScript.read(
                    this, imagePackFolderPickerCapability);
            imagePackFolderPickerOrigin = origin;
            boolean registered = false;
            ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "",
                    "folder_picker_script_loaded", "info",
                    ImagePackDiagnostics.details("scriptBytes", imagePackFolderPickerScript.length(),
                            "documentStartSupported", documentStartSupported));
            try {
                registered = ImagePackFolderPickerScript.installDocumentStart(
                        web, imagePackFolderPickerScript, origin);
            } catch (RuntimeException registrationError) {
                DiagnosticsLogger.error(this, "image-pack", "folder_picker_document_start", registrationError);
            }
            ImagePackDiagnostics.event(this, imagePackDiagnosticSessionId, "",
                    registered ? "folder_picker_document_start_registered" : "folder_picker_runtime_fallback_enabled",
                    "info", ImagePackDiagnostics.details("registered", registered,
                            "documentStartSupported", documentStartSupported, "origin", origin));
            if (registered) {
                DiagnosticsLogger.event(this, "INFO", "image-pack", "folder_picker_document_start_registered", null);
            } else {
                // The adapter is installed after page load when document-start injection is unavailable.
                DiagnosticsLogger.event(this, "INFO", "image-pack", "folder_picker_runtime_fallback_enabled", null);
            }
        } catch (Exception error) {
            imagePackFolderPickerScript = null;
            imagePackFolderPickerCapability = "";
            ImagePackDiagnostics.error(this, imagePackDiagnosticSessionId, "",
                    "folder_picker_script_load_failed", error);
            DiagnosticsLogger.error(this, "image-pack", "folder_picker_script_install", error);
        }

        if (!documentStartSupported) {
            if (imageGenStatus != null) imageGenStatus.setText(
                    "이 Android System WebView는 이미지 서버 연결 스크립트를 지원하지 않습니다. WebView 업데이트가 필요합니다.");
            return;
        }

        try {
            installDocumentStartAsset("imagegen-proxy.js", origin);
            installDocumentStartAsset("imagegen-studio-bridge.js", origin);
        } catch (Exception error) {
            if (imageGenStatus != null) imageGenStatus.setText(
                    "이미지 생성 연결 스크립트를 준비하지 못했습니다: " + msg(error));
        }
    }

    private void installDocumentStartAsset(String assetName, String origin) throws Exception {
        try (InputStream in = getAssets().open(assetName)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) >= 0) {
                if (count > 0) out.write(buffer, 0, count);
                if (out.size() > 64 * 1024) throw new IllegalStateException(assetName + " 파일이 너무 큽니다.");
            }
            String source = new String(out.toByteArray(), StandardCharsets.UTF_8);
            WebViewCompat.addDocumentStartJavaScript(
                    web, source, Collections.singleton(origin));
        }
    }

    private static final Object IMAGEGEN_LOCK = new Object();

    private File imageGenBackendRoot() {
        return new File(getFilesDir(), "imagegen/backend");
    }

    private String imageStudioModId(SafTree sessionTree) throws Exception {
        if (sessionTree != null) {
            String folderMod = sessionTree.imageStudioModId();
            if ("imagestudio".equals(folderMod)) return folderMod;
        }
        // ZIP-installed WML mods are served by the same overlay used by the
        // WebView. Detect the adapter there as well; never extract the ZIP.
        if (zipMods == null) return null;
        try (InputStream script = zipMods.open("wml/mods/imagestudio/mod.js")) {
            if (script == null) return null;
            byte[] bytes = new byte[65536];
            int used = 0;
            while (used < bytes.length) {
                int count = script.read(bytes, used, bytes.length - used);
                if (count < 0) break;
                if (count == 0) continue;
                used += count;
            }
            String source = new String(bytes, 0, used, StandardCharsets.UTF_8);
            int defineAt = source.indexOf("WML.define");
            if (defineAt < 0) return null;
            Matcher matcher = MOD_ID.matcher(source.substring(defineAt));
            return matcher.find() && "imagestudio".equals(matcher.group(1))
                    ? "imagestudio" : null;
        }
    }

    private boolean ensureImageGenBackend(SafTree sessionTree) throws Exception {
        // The WML mod is only the in-game adapter. The server implementation is
        // shipped in the launcher APK and never copied from the selected game.
        if (!"imagestudio".equals(imageStudioModId(sessionTree))) return false;
        File backend = ImageGenBackendInstaller.install(this, imageGenBackendRoot());
        return hasImageGenProject(backend);
    }

    private boolean hasImageGenProject(File backend) {
        File nested = new File(backend, "wayward-imagegen");
        File project = new File(nested, "src/cli.ts").isFile() ? nested : backend;
        return new File(project, "package.json").isFile() && new File(project, "src/cli.ts").isFile();
    }

    private void stopRetiredExternalProviderSession(SafTree sessionTree) {
        imageGenSessionMessage = "이전 버전의 외부 이미지 공급자 서버를 종료하고 NovelAI 전용 경로로 전환합니다…";
        refreshImageGenStatus();
        stopImageGenServerThen(new ImageServerModeCoordinator.Callback() {
            @Override public void onSuccess() {
                ensureImageGenServer(sessionTree, null);
            }
            @Override public void onFailure(String reason) {
                imageGenSessionMessage = "이전 외부 이미지 공급자 서버 종료 실패: " + reason;
                refreshImageGenStatus();
                finishImageGenCallbacks();
            }
        });
    }

    private void ensureImageGenServer(SafTree sessionTree, Runnable afterReady) {
        if (afterReady != null) imageGenReadyCallbacks.add(afterReady);
        if (sessionTree == null) {
            imageGenSessionMessage = "현재 게임 세션의 폴더를 확인할 수 없어 이미지 서버 자동 시작을 건너뛰었습니다.";
            finishImageGenCallbacks();
            refreshImageGenStatus();
            return;
        }

        if (manualImageGenPreparing) {
            imageGenSessionMessage = "이미지 생성 서버 준비가 진행 중입니다. 준비가 끝난 뒤 현재 세션을 다시 여세요.";
            refreshImageGenStatus();
            finishImageGenCallbacks();
            return;
        }
        if (imageGenCopying) {
            waitForImageGenReady();
            return;
        }

        final String providerMode = "novelai";
        final String version;
        try {
            String detected = imageStudioModId(sessionTree);
            imageStudioSessionDetected = "imagestudio".equals(detected);
            if (detected == null) {
                imageGenSessionMessage = "현재 세션의 WML Image Studio 모드가 없어 이미지 서버를 시작하지 않았습니다.";
                refreshImageGenStatus();
                finishImageGenCallbacks();
                return;
            }
            version = "launcher-imagegen:" + ImageGenBackendInstaller.VERSION + ":novelai";
        } catch (Exception e) {
            imageGenSessionMessage = "현재 세션의 Image Studio 확인 실패: " + msg(e);
            refreshImageGenStatus();
            finishImageGenCallbacks();
            return;
        }

        ImageGenStatusStore.State shared = ImageGenStatusStore.read(getFilesDir());
        if (shared.isAvailable() || shared.isStarting()) {
            if (!sameImageGenVersion(shared.backendVersion, version)) {
                if (shared.backendVersion != null && shared.backendVersion.contains(":launcher:")) {
                    stopRetiredExternalProviderSession(sessionTree);
                    return;
                }
                imageGenSessionMessage = "현재 세션 Image Studio 버전(" + version + ")이 실행 중 서버 버전("
                        + safeVersion(shared.backendVersion) + ")과 달라 공유하지 않았습니다. 실행 중인 서버를 중지한 뒤 세션을 다시 열어 주세요.";
                refreshImageGenStatus();
                finishImageGenCallbacks();
                return;
            }
            imageGenSessionMessage = "현재 세션의 Image Studio " + version + "을 공통 이미지 서버에 연결합니다.";
            waitForImageGenReady();
            return;
        }

        synchronized (IMAGEGEN_LOCK) {
            shared = ImageGenStatusStore.read(getFilesDir());
            if (shared.isAvailable() || shared.isStarting()) {
                if (!sameImageGenVersion(shared.backendVersion, version)) {
                    if (shared.backendVersion != null && shared.backendVersion.contains(":launcher:")) {
                        stopRetiredExternalProviderSession(sessionTree);
                        return;
                    }
                    imageGenSessionMessage = "다른 세션에서 다른 Image Studio 버전의 서버가 실행 중입니다. 현재 서버를 중지한 뒤 다시 시도해 주세요.";
                    refreshImageGenStatus();
                    finishImageGenCallbacks();
                    return;
                }
                waitForImageGenReady();
                return;
            }
            if (imageGenCopying) {
                waitForImageGenReady();
                return;
            }
            imageGenCopying = true;
        }

        imageGenSessionMessage = "현재 세션의 Image Studio 백엔드를 확인하고 런처 서버에 연결하는 중입니다…";
        refreshImageGenStatus();
        new Thread(() -> {
            String problem = null;
            File backend = imageGenBackendRoot();
            try {
                synchronized (IMAGEGEN_LOCK) {
                    if (!ensureImageGenBackend(sessionTree)) {
                        throw new IllegalStateException("현재 런처 APK에 포함된 ImageGen 서버 자산을 찾지 못했습니다.");
                    }
                }
                writeImageGenRuntimeConfig(backend, providerMode, "");
            } catch (Throwable error) {
                problem = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
            }
            final String failure = problem;
            runOnUiThread(() -> {
                imageGenCopying = false;
                if (failure != null) {
                    imageGenSessionMessage = "Image Studio 백엔드 준비 실패: " + failure;
                    refreshImageGenStatus();
                    finishImageGenCallbacks();
                    return;
                }
                startImageGenService(backend, version, providerMode, "");
                waitForImageGenReady();
            });
        }, "wayward-imagegen-session-prepare").start();
    }

    private static boolean sameImageGenVersion(String running, String requested) {
        if(running==null||requested==null||running.isEmpty()||requested.isEmpty())return false;
        // The engine mode is part of the identity so sessions cannot share an incompatible server.
        return running.equals(requested);
    }

    private static String safeVersion(String version) {
        return version == null || version.isEmpty() ? "알 수 없음" : version;
    }

    private void waitForImageGenReady() {
        if (imageGenReadyCallbacks.isEmpty() || imageGenPollRunnable != null) return;
        final long deadline = System.currentTimeMillis() + 18L * 60L * 1000L;
        imageGenPollRunnable = new Runnable() {
            @Override public void run() {
                ImageGenStatusStore.State state = ImageGenStatusStore.read(getFilesDir());
                boolean finished = state.isReady() || state.isAvailable()
                        || (!state.isStarting() && !imageGenCopying)
                        || System.currentTimeMillis() >= deadline;
                if (finished) {
                    imageGenPollRunnable = null;
                    finishImageGenCallbacks();
                    refreshImageGenStatus();
                } else {
                    imageGenHandler.postDelayed(this, 500);
                }
            }
        };
        imageGenHandler.post(imageGenPollRunnable);
    }

    private void finishImageGenCallbacks() {
        if (imageGenPollRunnable != null) {
            imageGenHandler.removeCallbacks(imageGenPollRunnable);
            imageGenPollRunnable = null;
        }
        List<Runnable> callbacks = new ArrayList<>(imageGenReadyCallbacks);
        imageGenReadyCallbacks.clear();
        for (Runnable callback : callbacks) {
            try { callback.run(); } catch (Exception ignored) {}
        }
    }

    private void startNovelAiServer(){
        startOrSwitchManagedImageGenServer("novelai","");
    }

    private void startComfyConnectionServer(){
        try{
            String url=ComfyEndpoint.normalizeOptional(comfyUrlInput==null?"":comfyUrlInput.getText().toString());
            startOrSwitchManagedImageGenServer("comfy",url);
        }catch(IllegalArgumentException error){
            imageGenSessionMessage="ComfyUI 주소 확인: "+msg(error);
            refreshImageGenStatus();
            Toast.makeText(this,imageGenSessionMessage,Toast.LENGTH_LONG).show();
        }
    }

    private void startOrSwitchManagedImageGenServer(String mode,String endpoint){
        ImageGenStatusStore.State running=ImageGenStatusStore.read(getFilesDir());
        String storedEndpoint=getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_COMFY_URL,"");
        boolean endpointChanged="comfy".equals(mode)&&!endpoint.equals(storedEndpoint==null?"":storedEndpoint);
        boolean sameMode=running.backendVersion!=null&&running.backendVersion.endsWith(":"+mode);
        if(running.isStarting()){
            imageGenSessionMessage="이미 이미지 서버를 시작하고 있습니다. 준비가 끝난 뒤 다시 시도해 주세요.";
            refreshImageGenStatus();
            return;
        }
        if(running.isAvailable()&&sameMode&&!endpointChanged){
            imageGenSessionMessage=running.isReady()
                    ? "런처 내장 "+("comfy".equals(mode)?"ComfyUI 중계":"NovelAI")+" 서버가 이미 실행 중입니다."
                    : (running.message.isEmpty() ? "이미지 서버 응답은 확인됐지만 공급자 설정이 아직 준비되지 않았습니다." : running.message);
            refreshImageGenStatus();
            Toast.makeText(this,imageGenSessionMessage,Toast.LENGTH_SHORT).show();
            return;
        }
        if("comfy".equals(mode)){
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_COMFY_URL,endpoint).apply();
        }
        if(running.isAvailable()){
            imageGenSessionMessage="서버 설정 변경을 적용하기 위해 내장 이미지 서버를 재시작합니다…";
            refreshImageGenStatus();
            stopImageGenServer();
            waitForImageGenStopThenStart(mode,endpoint,0);
            return;
        }
        startManagedImageGenServer(mode,endpoint);
    }

    private void waitForImageGenStopThenStart(String mode,String endpoint,int attempt){
        ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
        if(!state.isAvailable()&&!state.isStarting()){
            startManagedImageGenServer(mode,endpoint);
            return;
        }
        if(attempt>=20){
            imageGenSessionMessage="기존 이미지 서버가 아직 종료되지 않았습니다. 중지 버튼으로 종료한 뒤 다시 실행해 주세요.";
            refreshImageGenStatus();
            return;
        }
        imageGenHandler.postDelayed(()->waitForImageGenStopThenStart(mode,endpoint,attempt+1),250);
    }

    private void openImageGenPanel(){
        if (web == null || tree == null) {
            MainActivity session = findActiveSessionActivity();
            if (session != null && session != this) {
                String sessionId = session.activeProfileId;
                // Resolve the owner through its URI-keyed document task. Component-only
                // reordering can select a different MainActivity instance.
                try {
                    session.openImageGenPanel();
                    Intent route = new Intent(this, GameSessionActivity.class);
                    route.setData(Uri.parse("wayward://session/" + Uri.encode(sessionId)));
                    route.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
                    startActivity(route);
                    DiagnosticsLogger.event(this,"INFO","imagegen","session_settings_routed",null);
                    return;
                } catch (Throwable error) {
                    DiagnosticsLogger.error(this,"imagegen","session_settings_route_failed",error);
                }
            }
            Toast.makeText(this,"게임 세션을 먼저 실행해 Image Studio 모드를 불러와 주세요.",Toast.LENGTH_LONG).show();
            return;
        }
        Runnable openSettings = () -> {
            ImageGenStatusStore.State state = ImageGenStatusStore.read(getFilesDir());
            if (!state.isAvailable()) {
                String detail = state.message == null || state.message.isEmpty()
                        ? "이미지 서버 응답을 확인하지 못했습니다." : state.message;
                Toast.makeText(this,detail,Toast.LENGTH_LONG).show();
                return;
            }
            if (home != null) home.setVisibility(View.GONE);
            web.setVisibility(View.VISIBLE);
            web.bringToFront();
            web.postDelayed(() -> {
                if (web == null) return;
                web.evaluateJavascript(
                        "(async()=>{const bridge=window.WaywardLauncherImageStudio;"
                        + "if(!bridge)return 'launcher_bridge_missing';"
                        + "const result=await bridge.openGenerationSettings();"
                        + "return result&&result.ok?'opened':(result&&result.reason)||'open_failed';})()",
                        value -> {
                            if (value == null || !value.contains("opened")) {
                                String reason = value == null ? "unknown" : value;
                                Toast.makeText(this,"Image Studio 설정 화면을 열지 못했습니다: "+reason,Toast.LENGTH_LONG).show();
                            }
                        });
            }, 100L);
        };
        // A verified active session can reuse the running service without a
        // second SAF scan. Otherwise retain the normal detection/startup flow.
        ImageGenStatusStore.State existing = ImageGenStatusStore.read(getFilesDir());
        if (imageStudioSessionDetected && existing.isAvailable()) openSettings.run();
        else ensureImageGenServer(tree, openSettings);
    }

    private void registerSessionActivity() {
        String id = activeProfileId;
        if (id == null || !id.matches("[a-f0-9]{32}") || web == null || tree == null) return;
        SESSION_ACTIVITIES.put(id, new WeakReference<>(this));
        LAST_ACTIVE_SESSION_ID = id;
    }

    private static MainActivity findActiveSessionActivity() {
        String lastId = LAST_ACTIVE_SESSION_ID;
        if (lastId != null && !lastId.isEmpty()) {
            WeakReference<MainActivity> last = SESSION_ACTIVITIES.get(lastId);
            MainActivity activity = last == null ? null : last.get();
            if (activity != null && !activity.isFinishing()
                    && activity.web != null && activity.tree != null) return activity;
            if (last != null && activity == null) SESSION_ACTIVITIES.remove(lastId, last);
        }
        for (Map.Entry<String, WeakReference<MainActivity>> entry : SESSION_ACTIVITIES.entrySet()) {
            MainActivity activity = entry.getValue().get();
            if (activity != null && !activity.isFinishing()
                    && activity.web != null && activity.tree != null) {
                LAST_ACTIVE_SESSION_ID = entry.getKey();
                return activity;
            }
            if (activity == null) SESSION_ACTIVITIES.remove(entry.getKey(), entry.getValue());
        }
        LAST_ACTIVE_SESSION_ID = "";
        return null;
    }

    private void unregisterSessionActivity() {
        for (Map.Entry<String, WeakReference<MainActivity>> entry : SESSION_ACTIVITIES.entrySet()) {
            if (entry.getValue().get() == this) {
                SESSION_ACTIVITIES.remove(entry.getKey(), entry.getValue());
                if (entry.getKey().equals(LAST_ACTIVE_SESSION_ID)) LAST_ACTIVE_SESSION_ID = "";
            }
        }
        if (LAST_ACTIVE_SESSION_ID.isEmpty()) findActiveSessionActivity();
    }

    private void startManagedImageGenServer(String mode,String comfyUrl){
        if (!"novelai".equals(mode) && !"comfy".equals(mode)) {
            imageGenSessionMessage = "지원하지 않는 이미지 생성 서버 모드입니다.";
            refreshImageGenStatus();
            return;
        }
        synchronized(IMAGEGEN_LOCK){
            ImageGenStatusStore.State running=ImageGenStatusStore.read(getFilesDir());
            if(running.isAvailable()||running.isStarting()){
                imageGenSessionMessage=running.isReady()
                        ? "이미 런처 내장 이미지 서버가 실행 중입니다. ComfyUI 주소를 바꾸려면 주소를 입력한 뒤 연결 버튼을 누르세요."
                        : (running.message.isEmpty() ? "이미지 서버 응답은 확인됐지만 공급자 설정이 아직 준비되지 않았습니다." : running.message);
                refreshImageGenStatus();
                Toast.makeText(this,imageGenSessionMessage,Toast.LENGTH_LONG).show();
                return;
            }
            if(imageGenCopying||manualImageGenPreparing){
                imageGenSessionMessage="내장 이미지 서버를 준비하고 있습니다. 준비가 끝난 뒤 다시 시도해 주세요.";
                refreshImageGenStatus();
                Toast.makeText(this,imageGenSessionMessage,Toast.LENGTH_LONG).show();
                return;
            }
            manualImageGenPreparing=true;
        }

        final File backend=imageGenBackendRoot();
        final String requestedUrl=comfyUrl==null?"":comfyUrl.trim();
        imageGenSessionMessage=("novelai".equals(mode)?"NovelAI":"ComfyUI 연결")+" 런처 내장 서버를 준비하고 있습니다…";
        refreshImageGenStatus();
        new Thread(()->{
            String failure=null;
            try{
                ImageGenBackendInstaller.install(this,backend);
                // Server availability is independent of provider credentials.
                // NovelAI credentials are supplied only to the NovelAI runtime.
                writeImageGenRuntimeConfig(backend,mode,requestedUrl);
            }catch(Throwable error){
                failure=error.getMessage()==null?error.getClass().getSimpleName():error.getMessage();
            }
            final String problem=failure;
            runOnUiThread(()->{
                if(problem!=null){
                    manualImageGenPreparing=false;
                    imageGenSessionMessage="내장 이미지 서버 준비 실패: "+problem;
                    try { ImageGenStatusStore.write(getFilesDir(),false,false,imageGenSessionMessage,""); }
                    catch (Exception ignored) {}
                    refreshImageGenStatus();
                    Toast.makeText(this,imageGenSessionMessage,Toast.LENGTH_LONG).show();
                    return;
                }
                String launchVersion="launcher-imagegen:"+ImageGenBackendInstaller.VERSION+":"+mode;
                try {
                    ImageGenStatusStore.write(getFilesDir(),false,true,"런처 내장 ImageGen 서버 시작 중…",launchVersion);
                } catch (Exception error) {
                    manualImageGenPreparing=false;
                    imageGenSessionMessage="이미지 서버 상태를 저장하지 못했습니다: "+msg(error);
                    refreshImageGenStatus();
                    return;
                }
                imageGenReadyCallbacks.add(()->{
                    ImageGenStatusStore.State state=ImageGenStatusStore.read(getFilesDir());
                    if(!state.isReady())imageGenSessionMessage=state.message;
                    refreshImageGenStatus();
                });
                startImageGenService(backend,launchVersion,mode,requestedUrl);
                manualImageGenPreparing=false;
                refreshImageGenStatus();
                waitForImageGenReady();
            });
        },"wayward-imagegen-bundled-prepare").start();
    }

    private void writeImageGenRuntimeConfig(File backend,String mode,String comfyUrl)throws Exception{
        File project=new File(backend,"wayward-imagegen");
        if(!new File(project,"src/cli.ts").isFile())throw new IllegalStateException("내장 wayward-imagegen/src/cli.ts가 없습니다.");
        JSONObject config=new JSONObject();
        config.put("host","127.0.0.1");
        config.put("port",8189);
        config.put("imagesDir",new File(getFilesDir(),"imagegen/images").getAbsolutePath());
        config.put("stateDir",new File(getFilesDir(),"imagegen/state").getAbsolutePath());
        config.put("comfyUrl",comfyUrl==null||comfyUrl.isEmpty()?"http://127.0.0.1:8188":comfyUrl);
        config.put("imageProvider","novelai".equals(mode)?"nai":"sdxl");
        config.put("naiModel","nai-diffusion-4-5-full");
        // Android has no bundled sharp binary; PNG is the supported no-dependency path.
        config.put("webp",false);
        config.put("requireWebp",false);
        File images=new File(getFilesDir(),"imagegen/images");
        File state=new File(getFilesDir(),"imagegen/state");
        if(!images.isDirectory()&&!images.mkdirs()&&!images.isDirectory())throw new IllegalStateException("이미지 저장 폴더를 만들지 못했습니다.");
        if(!state.isDirectory()&&!state.mkdirs()&&!state.isDirectory())throw new IllegalStateException("이미지 상태 폴더를 만들지 못했습니다.");
        synchronizeImageGenProviderSetting(state,mode);
        File output=new File(project,"wayward-imagegen.config.json");
        File temporary=new File(project,"wayward-imagegen.config.json.tmp");
        try(FileOutputStream stream=new FileOutputStream(temporary)){
            stream.write(config.toString().getBytes(StandardCharsets.UTF_8));
            stream.flush();
            stream.getFD().sync();
        }
        try{
            java.nio.file.Files.move(temporary.toPath(),output.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
        }catch(java.nio.file.AtomicMoveNotSupportedException error){
            java.nio.file.Files.move(temporary.toPath(),output.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private void synchronizeImageGenProviderSetting(File stateDirectory,String mode)throws Exception{
        File settingsFile=new File(stateDirectory,"anima-settings.json");
        if(!settingsFile.isFile())return;
        if(settingsFile.length()<=0||settingsFile.length()>2*1024*1024)throw new IllegalStateException("기존 Image Studio 설정 파일 크기가 올바르지 않습니다.");
        byte[] bytes=java.nio.file.Files.readAllBytes(settingsFile.toPath());
        org.json.JSONObject settings=new org.json.JSONObject(new String(bytes,StandardCharsets.UTF_8));
        String provider="novelai".equals(mode)?"nai":"sdxl";
        settings.put("imageProvider",provider);
        // Credentials are supplied by Android Keystore, never persisted here.
        settings.put("naiToken","");
        File temporary=new File(stateDirectory,"anima-settings.json.tmp");
        try(FileOutputStream output=new FileOutputStream(temporary,false)){
            output.write((settings.toString()+"\n").getBytes(StandardCharsets.UTF_8));
            output.flush();
            output.getFD().sync();
        }
        try{
            java.nio.file.Files.move(temporary.toPath(),settingsFile.toPath(),
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }catch(java.nio.file.AtomicMoveNotSupportedException error){
            java.nio.file.Files.move(temporary.toPath(),settingsFile.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }finally{
            if(temporary.exists())temporary.delete();
        }
    }

    private void startImageGenService(File backend, String version) {
        startImageGenService(backend,version,"default","");
    }

    private void startImageGenService(File backend,String version,String launchMode,String comfyUrl){
        Intent intent = new Intent(this, ImageGenService.class);
        intent.setAction(ImageGenService.ACTION_START);
        intent.putExtra(ImageGenService.EXTRA_BACKEND_ROOT, backend.getAbsolutePath());
        intent.putExtra(ImageGenService.EXTRA_BACKEND_VERSION, version);
        intent.putExtra(ImageGenService.EXTRA_LAUNCH_MODE, launchMode);
        intent.putExtra(ImageGenService.EXTRA_COMFY_URL, comfyUrl==null?"":comfyUrl);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            imageGenSessionMessage = "Wayward ImageGen " + version + " 서버 시작 요청을 전달했습니다.";
            refreshImageGenStatus();
        } catch (Throwable error) {
            DiagnosticsLogger.error(this,"imagegen","service_start_request_failed",error);
            String message = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
            imageGenSessionMessage = "이미지 서버 시작 요청 실패: " + message;
            try {
                ImageGenStatusStore.write(getFilesDir(), false, false, imageGenSessionMessage, version);
            } catch (Exception ignored) {}
            refreshImageGenStatus();
        }
    }


    private void stopImageGenServer() {
        DiagnosticsLogger.event(this,"INFO","imagegen","stop_requested",null);
        Intent intent = new Intent(this, ImageGenService.class).setAction(ImageGenService.ACTION_STOP);
        try {
            startService(intent);
        } catch (Exception ignored) {
            stopService(new Intent(this, ImageGenService.class));
        }
        imageGenSessionMessage = "이미지 생성 서버 중지 요청을 보냈습니다.";
        if (imageGenStatus != null) imageGenStatus.setText(imageGenSessionMessage);
    }

    private void refreshImageGenStatus() {
        if (imageGenStatus == null) return;
        ImageGenStatusStore.State state = ImageGenStatusStore.read(getFilesDir());
        if (state.isReady()) {
            boolean comfy = state.backendVersion != null && state.backendVersion.endsWith(":comfy");
            String endpoint = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_COMFY_URL, "");
            if (comfy && (endpoint == null || endpoint.trim().isEmpty())) {
                imageGenStatus.setText("로컬 ComfyUI 중계 서버 실행됨 · PC 주소 미설정 · 연결 대기 중 · 127.0.0.1:8189");
            } else {
                imageGenStatus.setText("런처 내장 ImageGen " + ImageGenBackendInstaller.VERSION + " 실행 중 · 127.0.0.1:8189");
            }
        }
        else if (state.isAvailable()) imageGenStatus.setText(state.message.isEmpty()
                ? "이미지 서버 응답 확인됨 · 공급자 설정을 확인해 주세요." : state.message);
        else if (state.isStarting()) imageGenStatus.setText(state.message.isEmpty() ? "이미지 생성 서버 시작 중…" : state.message);
        else if (imageGenCopying || manualImageGenPreparing) imageGenStatus.setText("이미지 생성 백엔드 준비 중…");
        else if (state.ready && !state.isFresh()) imageGenStatus.setText("이미지 생성 서비스 heartbeat가 끊겼습니다. 현재 세션을 다시 열면 서버를 재시작합니다.");
        else if (!state.message.isEmpty()) imageGenStatus.setText(state.message);
        else if (imageGenSessionMessage != null && !imageGenSessionMessage.isEmpty()) imageGenStatus.setText(imageGenSessionMessage);
        else imageGenStatus.setText("서버가 실행되지 않았습니다.");
    }

    private static void deleteFileTree(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteFileTree(child);
        }
        file.delete();
    }

    private void showHomePanel(){runOnUiThread(()->{
        if(web!=null&&sessionProfileId(getIntent())!=null){
            logGameLifecycle("INFO","game_return_requested",activeProfileId,activeGameLaunchRequestId,
                    "launcher_menu");
        }
        if(web!=null)web.setVisibility(View.GONE);
        if(home!=null)home.setVisibility(View.VISIBLE);
        refreshStatus();refreshImageGenStatus();renderImageModePanel();
    });}
    private void destroyWeb(){
        if(webDownloadHandler!=null){webDownloadHandler.cancelPending();webDownloadHandler=null;}
        if(webFileChooser!=null){webFileChooser.cancelPending();webFileChooser=null;}
        if(imagePackDirectoryAccess!=null){imagePackDirectoryAccess.cancelPending();imagePackDirectoryAccess=null;}
        imagePackFolderPickerCapability = "";
        if(web==null)return;
        logGameLifecycle("INFO","game_webview_destroyed",activeProfileId,activeGameLaunchRequestId,
                "destroyWeb");
        web.removeJavascriptInterface("WMLHost");root.removeView(web);web.stopLoading();web.loadUrl("about:blank");web.destroy();web=null;
        webViewInstanceId="";gamePageLoaded=false;gamePageLoadFailed=false;
    }
    @Override public void onBackPressed(){
        if(web!=null&&web.getVisibility()==View.VISIBLE){
            if(web.canGoBack()){
                web.goBack();
            }else if(sessionProfileId(getIntent())!=null){
                logGameLifecycle("INFO","game_return_requested",activeProfileId,activeGameLaunchRequestId,
                        "system_back_finish");
                DiagnosticsLogger.event(this,"INFO","launcher","game_session_back_to_launcher",null);
                finish();
            }else{
                showHomePanel();
            }
            return;
        }
        super.onBackPressed();
    }
    @Override protected void onDestroy(){
        String sessionId=sessionProfileId(getIntent());
        if(sessionId!=null)logGameLifecycle("INFO","game_session_destroyed",sessionId,
                activeGameLaunchRequestId,"onDestroy");
        unregisterSessionActivity();
        if(sessionId!=null&&findSessionActivity(sessionId)==null)RUNNING_SESSIONS.remove(sessionId);
        logGameLifecycle("INFO","activity_destroy",sessionId,activeGameLaunchRequestId,"onDestroy");
        if(imagePackDirectoryAccess!=null)imagePackDirectoryAccess.closeAllFileStreams();
        destroyWeb();if(zipMods!=null)zipMods.close();super.onDestroy();
    }
    private String msg(Throwable e){return e==null||e.getMessage()==null?"알 수 없는 오류":e.getMessage();}
    private final class HostBridge{
        private boolean hasImagePackBridgeCapability(String capability) {
            return ImagePackFolderPickerScript.matchesCapability(
                    imagePackFolderPickerCapability, capability);
        }
        private String imagePackBridgeDenied() {
            return "{\"ok\":false,\"name\":\"SecurityError\",\"message\":\"The SAF bridge capability is invalid.\"}";
        }
        @JavascriptInterface public String version(){return "1.0.0";}
        @JavascriptInterface public void recordImagePackDiagnostic(String requestId, String stage, String detailsJson){
            ImagePackDiagnostics.javascriptEvent(MainActivity.this, imagePackDiagnosticSessionId,
                    requestId, stage, detailsJson);
        }
        @JavascriptInterface public boolean beginBlobDownload(String requestId,String filename,String mimeType,long expectedBytes){
            WebDownloadHandler handler=webDownloadHandler;
            return handler!=null && handler.beginDownload(requestId,filename,mimeType,expectedBytes);
        }
        @JavascriptInterface public boolean appendBlobDownloadChunk(String requestId,String base64Bytes){
            WebDownloadHandler handler=webDownloadHandler;
            return handler!=null && handler.appendChunk(requestId,base64Bytes);
        }
        @JavascriptInterface public boolean finishBlobDownload(String requestId){
            WebDownloadHandler handler=webDownloadHandler;
            return handler!=null && handler.finishDownload(requestId);
        }
        @JavascriptInterface public void abortBlobDownload(String requestId){
            WebDownloadHandler handler=webDownloadHandler;
            if(handler!=null)handler.abortDownload(requestId);
        }
        @JavascriptInterface public void chooseImagePackFolder(String requestId, String capability, String mode, String initialUri){
            // JavascriptInterface methods run on WebView's private background thread.
            // WebView state and native Activity launches must be handled on the UI thread.
            MainActivity.this.runOnUiThread(() ->
                    chooseImagePackFolderOnUiThread(requestId, capability, mode, initialUri));
        }
        private void chooseImagePackFolderOnUiThread(String requestId, String capability, String mode, String initialUri) {
            try {
                boolean trustedOrigin = web != null && activeProfileId != null
                        && ImagePackFolderPickerScript.isSameOrigin(web.getUrl(), imagePackFolderPickerOrigin)
                        && imagePackFolderPickerOrigin.equals(sessionOrigin(activeProfileId));
                boolean trustedCapability = ImagePackFolderPickerScript.matchesCapability(
                        imagePackFolderPickerCapability, capability);
                if (!trustedOrigin || !trustedCapability) {
                    ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, requestId,
                            "wmlhost_choose_folder_rejected", "error",
                            ImagePackDiagnostics.details("requestSource", "showDirectoryPicker",
                                    "originValidated", trustedOrigin, "capabilityValidated", trustedCapability));
                    if (imagePackDirectoryAccess != null) imagePackDirectoryAccess.rejectRequest(requestId,
                            trustedOrigin ? "NotAllowedError" : "SecurityError",
                            "The image-pack folder request was rejected by the native security boundary.");
                    return;
                }
                ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, requestId,
                        "wmlhost_choose_folder_entered", "info",
                        ImagePackDiagnostics.details("requestSource", "showDirectoryPicker",
                                "originValidated", true, "capabilityValidated", true));
                if (imagePackDirectoryAccess != null) {
                    imagePackDirectoryAccess.openFolderPicker(requestId, mode, initialUri);
                } else {
                    ImagePackDiagnostics.event(MainActivity.this, imagePackDiagnosticSessionId, requestId,
                            "wmlhost_directory_access_missing", "error", null);
                    if (web != null) web.evaluateJavascript("(function(){if(typeof window.__waywardNativeImagePackPickerDispatch==='function')"
                            + "window.__waywardNativeImagePackPickerDispatch(" + JSONObject.quote(requestId)
                            + ",{ok:false,name:'NotReadableError',message:'Native folder access is unavailable.',state:'FAILED'});})()", null);
                }
            } catch (Exception error) {
                ImagePackDiagnostics.error(MainActivity.this, imagePackDiagnosticSessionId, requestId,
                        "wmlhost_choose_folder_ui_dispatch_failed", error);
                if (imagePackDirectoryAccess != null) imagePackDirectoryAccess.rejectRequest(requestId,
                        "NotAllowedError", "Android could not start the system image-pack folder picker.");
            }
        }
        @JavascriptInterface public String listImagePackDirectoryForRequest(String capability, String documentUri, String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            if (imagePackDirectoryAccess == null) return "{\"ok\":false,\"name\":\"NotFoundError\"}";
            if (documentUri != null && documentUri.startsWith("__WAYWARD_DIR_START__:")) {
                return imagePackDirectoryAccess.startListDirectory(
                        documentUri.substring("__WAYWARD_DIR_START__:".length()), requestId);
            }
            if (documentUri != null && documentUri.startsWith("__WAYWARD_DIR_ACK__:")) {
                try {
                    int batchIndex = Integer.parseInt(
                            documentUri.substring("__WAYWARD_DIR_ACK__:".length()));
                    if (batchIndex < 0) throw new NumberFormatException("negative batch index");
                    return imagePackDirectoryAccess.acknowledgeDirectoryBatch(requestId, batchIndex)
                            ? "{\"ok\":true}"
                            : "{\"ok\":false,\"name\":\"AbortError\",\"message\":\"The SAF batch is no longer active.\"}";
                } catch (NumberFormatException invalidBatch) {
                    return "{\"ok\":false,\"name\":\"TypeError\",\"message\":\"The SAF batch index is invalid.\"}";
                }
            }
            if (documentUri != null && documentUri.startsWith("__WAYWARD_DIR_CANCEL__:")) {
                boolean cancelled = imagePackDirectoryAccess.cancelDirectoryList(requestId);
                return "{\"ok\":true,\"cancelled\":" + cancelled + "}";
            }
            if (documentUri != null && documentUri.startsWith("__WAYWARD_DIR_RELEASE__:")) {
                imagePackDirectoryAccess.releaseDirectoryTreeForRequest(requestId);
                return "{\"ok\":true}";
            }
            return imagePackDirectoryAccess.listDirectoryJson(documentUri,requestId);
        }
        @JavascriptInterface public String readImagePackFileForRequest(String capability, String documentUri, String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.readFileJson(documentUri,requestId);
        }
        @JavascriptInterface public String openImagePackFileStreamForRequest(String capability, String documentUri, String start, String length, String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.openFileStreamJson(documentUri,start,length,requestId);
        }
        @JavascriptInterface public String readImagePackFileStreamChunkForRequest(String capability, String streamId, String maxBytes, String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.readFileStreamChunkJson(streamId,maxBytes,requestId);
        }
        @JavascriptInterface public String closeImagePackFileStreamForRequest(String capability, String streamId, String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.closeFileStreamJson(streamId,requestId);
        }
        @JavascriptInterface public String createImagePackFile(String capability, String parentUri,String name,String mime,String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.createFileJson(parentUri,name,mime,requestId);
        }
        @JavascriptInterface public String writeImagePackFile(String capability, String documentUri,String mime,String data,String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.writeFileJson(documentUri,mime,data,requestId);
        }
        @JavascriptInterface public String createImagePackDirectory(String capability, String parentUri,String name,String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.createDirectoryJson(parentUri,name,requestId);
        }
        @JavascriptInterface public String deleteImagePackEntry(String capability, String documentUri,String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.deleteEntryJson(documentUri,requestId);
        }
        @JavascriptInterface public String resolveImagePackEntry(String capability, String parentUri,String targetUri,String requestId){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.resolveEntryJson(parentUri,targetUri,requestId);
        }
        @JavascriptInterface public String getImagePackFolderInfo(String capability){
            if (!hasImagePackBridgeCapability(capability)) return imagePackBridgeDenied();
            return imagePackDirectoryAccess==null?"{\"ok\":false,\"name\":\"NotFoundError\"}":imagePackDirectoryAccess.getFolderInfoJson();
        }
        @JavascriptInterface public String listModIds(){
            try{JSONObject r=new JSONObject();JSONArray a=new JSONArray();for(String id:allModIds())a.put(id);r.put("ok",true);r.put("ids",a);return r.toString();}
            catch(Exception e){try{JSONObject r=new JSONObject();r.put("ok",false);r.put("ids",new JSONArray());return r.toString();}catch(Exception ignored){return "{}";}}
        }
        @JavascriptInterface public void menu(){showHomePanel();}
        @JavascriptInterface public void startGoogleDriveAuth(String nonce){
            startGoogleDriveAuthWithPolicy(nonce,false);
        }
        @JavascriptInterface public void startGoogleDriveAuthWithPolicy(String nonce,boolean forceSelectAccount){
            if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return;
            runOnUiThread(()->beginGoogleDriveAuth(nonce,forceSelectAccount));
        }
        @JavascriptInterface public void cancelGoogleDriveAuth(String nonce){
            if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return;
            runOnUiThread(()->clearGoogleDriveAuthRequest(nonce));
        }
        @JavascriptInterface public void revokeGoogleDriveAccess(String nonce){
            if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return;
            runOnUiThread(()->{
                try{
                    RevokeAccessRequest request=RevokeAccessRequest.builder()
                            .setScopes(Collections.singletonList(
                                    new Scope("https://www.googleapis.com/auth/drive.appdata")))
                            .build();
                    Identity.getAuthorizationClient(MainActivity.this).revokeAccess(request)
                            .addOnSuccessListener(unused->storeGoogleRevokeResult(nonce,true,null))
                            .addOnFailureListener(error->storeGoogleRevokeResult(nonce,false,msg(error)));
                }catch(Throwable error){
                    storeGoogleRevokeResult(nonce,false,msg(error));
                }
            });
        }
        @JavascriptInterface public String takePendingStateForNonce(String nonce){
            if(nonce==null||!nonce.matches("[a-f0-9]{48}"))return "";
            String result=PENDING_GOOGLE_AUTH_RESULTS.remove(nonce);
            return result==null?"":result;
        }
        @JavascriptInterface public void clearGoogleAccessToken(String token){
            if(token==null||token.isEmpty()||token.length()>4096)return;
            runOnUiThread(()->{
                try{
                    Identity.getAuthorizationClient(MainActivity.this)
                            .clearToken(ClearTokenRequest.builder().setToken(token).build())
                            .addOnFailureListener(error->DiagnosticsLogger.error(MainActivity.this,"oauth","google_access_token_cache_clear_failed",error));
                }catch(Throwable error){
                    DiagnosticsLogger.error(MainActivity.this,"oauth","google_access_token_cache_clear_failed",error);
                }
            });
        }
        @JavascriptInterface public void imageGenProxyFetch(String requestId,String method,String path,String headersJson,String bodyBase64){
            boolean remotePcMode=IMAGE_MODE_REMOTE_PC.equals(currentImageMode());
            ImageGenProxy.dispatch(web,requestId,method,path,headersJson,bodyBase64,remotePcMode);
        }
        @JavascriptInterface public String imageGenRuntimeStatus(){
            boolean remotePcMode=IMAGE_MODE_REMOTE_PC.equals(currentImageMode());
            ImageGenStatusStore.State state=ImageGenStatusStore.read(MainActivity.this.getFilesDir());
            try{
                JSONObject value=new JSONObject();
                if(remotePcMode){
                    boolean ready=RemoteHostStore.isReady(MainActivity.this);
                    value.put("available",ready);
                    value.put("starting",false);
                    value.put("ready",ready);
                    value.put("backendVersion","remote-pc:v1");
                    value.put("engine","remote-pc");
                    value.put("message",ready?"페어링된 PC Remote Host를 사용합니다.":"PC 페어링과 승인된 폴더 선택이 필요합니다.");
                }else{
                    value.put("available",state.isAvailable());
                    value.put("starting",state.isStarting());
                    value.put("ready",state.isReady());
                    value.put("backendVersion",state.backendVersion);
                    String[] parts=state.backendVersion.split(":");
                    value.put("engine",parts.length>=3?parts[2]:"unknown");
                    value.put("message",state.message);
                }
                return value.toString();
            }catch(Exception ignored){return "{\"available\":false,\"starting\":false,\"ready\":false,\"backendVersion\":\"\",\"engine\":\"unknown\"}";}
        }
        @JavascriptInterface public void logImageProviderDiagnostic(String event,String detailsJson){
            ImagePipelineDiagnostics.recordJson(MainActivity.this,event,detailsJson);
        }
        @JavascriptInterface public String takePendingState(){return "";}
        @JavascriptInterface public String saveFile(String name,String mime,String encoded){try{saveExport(name,mime,encoded);return null;}catch(Exception e){return msg(e);}}
    }
    private void saveExport(String req,String mime,String encoded)throws Exception{
        String name=req==null?"wayward-export.bin":req.replace("/","_").replace("\\\\","_").trim();if(name.isEmpty()||name.equals(".")||name.equals(".."))name="wayward-export.bin";
        if(encoded==null||encoded.length()>140*1024*1024)throw new IllegalArgumentException("파일이 너무 큽니다.");
        byte[] bytes=android.util.Base64.decode(encoded,android.util.Base64.DEFAULT);ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Wayward");v.put(MediaStore.Downloads.IS_PENDING,1);
        Uri item=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(item==null)throw new IllegalStateException("Download/Wayward 저장 실패");
        boolean ok=false;try(OutputStream out=getContentResolver().openOutputStream(item,"w")){if(out==null)throw new IllegalStateException("파일 열기 실패");out.write(bytes);out.flush();ContentValues d=new ContentValues();d.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(item,d,null,null);ok=true;}finally{if(!ok)getContentResolver().delete(item,null,null);}
    }
    private static final class FolderHandler implements WebViewAssetLoader.PathHandler{
        private static final String CORE="wml/runtime/wml-core.js";private static final String BUNDLED_SYMBOL_TABLE="wml/symbols/2026-11-01.js";private final SafTree tree;private final android.content.res.AssetManager assets;private final ZipModStore zipMods;private final String origin;
        FolderHandler(SafTree t,android.content.res.AssetManager a,ZipModStore z,String o){tree=t;assets=a;zipMods=z;origin=o;}
        @Override public WebResourceResponse handle(String p){return serveGamePath(p);}
        static boolean isGameRequestPath(String path){
            return path!=null&&path.startsWith("/game/");
        }
        WebResourceResponse serveGamePath(String relative){
            WebResourceResponse result=serve(relative);
            return result!=null?result:response(404,"Not Found","text/plain","Game resource not found");
        }
        static boolean isImageRequestPath(String path){
            return path!=null&&path.regionMatches(true,0,"/images/",0,8);
        }
        static boolean isLocalOnlyCharacterImagePath(String path){
            String prefix="/images/illustrious/characters/";
            return path!=null&&path.regionMatches(true,0,prefix,0,prefix.length());
        }
        static boolean isImageAssetPath(String path){
            return path!=null&&path.regionMatches(true,0,"images/",0,7);
        }
        WebResourceResponse serveImagePath(String relative){
            WebResourceResponse result=serveLocalImage(relative);
            return result!=null?result:response(404,"Not Found","text/plain","Local image not found");
        }
        WebResourceResponse serveExternalImagePath(String relative){
            return serveLocalImage(relative);
        }
        private WebResourceResponse serveLocalImage(String relative){
            String path=normal(relative);
            if(path==null)return response(400,"Bad Request","text/plain","Invalid local image path");
            String filePath="images/"+path;
            try{
                InputStream in=tree==null?null:tree.openImage(filePath);
                if(in==null&&zipMods!=null)in=zipMods.open(filePath);
                if(in==null)return null;
                String m=mime(filePath);
                return new WebResourceResponse(m,text(m)?"UTF-8":null,200,"OK",headers(filePath),in);
            }catch(Exception e){
                return response(500,"Read Error","text/plain","Image read error: "+e.getMessage());
            }
        }
        WebResourceResponse serve(String raw){
            try{
                String p=normal(raw);
                if(p==null)return response(404,"Not Found","text/plain","Not found");
                if(tree==null&&!BUNDLED_SYMBOL_TABLE.equals(p))
                    return response(404,"Not Found","text/plain","Not found");
                InputStream in=tree==null?null:(isImageAssetPath(p)?tree.openImage(p):tree.open(p));
                if(in==null&&zipMods!=null)in=zipMods.open(p);
                if(in==null&&BUNDLED_SYMBOL_TABLE.equals(p))in=assets.open(BUNDLED_SYMBOL_TABLE);
                if(in==null)return null;
                if(p.toLowerCase(Locale.ROOT).endsWith(".html")||p.toLowerCase(Locale.ROOT).endsWith(".htm"))in=mobileViewport(in);
                if(CORE.equals(p))in=new SequenceInputStream(assets.open("wml-folder-bootstrap.js"),in);
                String m=mime(p);
                return new WebResourceResponse(m,text(m)?"UTF-8":null,200,"OK",headers(p),in);
            }catch(Exception e){return response(500,"Read Error","text/plain","Read error: "+e.getMessage());}
        }
        static InputStream mobileViewport(InputStream source)throws Exception{
            ByteArrayOutputStream prefix=new ByteArrayOutputStream();
            byte[] chunk=new byte[4096];int total=0,n,closeEnd=-1;
            while(total<128*1024){
                n=source.read(chunk,0,Math.min(chunk.length,128*1024-total));
                if(n<0)break;
                if(n==0)continue;
                prefix.write(chunk,0,n);total+=n;
                byte[] probe=prefix.toByteArray();
                closeEnd=indexOfIgnoreCase(probe,"</head>",0,probe.length);
                if(closeEnd>=0){closeEnd+=7;break;}
            }
            byte[] original=prefix.toByteArray();
            if(closeEnd<0)return new SequenceInputStream(new ByteArrayInputStream(original),source);
            int headStart=indexOfIgnoreCase(original,"<head",0,closeEnd);
            if(headStart<0)return new SequenceInputStream(new ByteArrayInputStream(original),source);
            int headTagEnd=indexOfByte(original,(byte)'>',headStart,closeEnd);
            if(headTagEnd<0)return new SequenceInputStream(new ByteArrayInputStream(original),source);
            int closeStart=closeEnd-7;
            String head=new String(original,headStart,closeStart-headStart,StandardCharsets.ISO_8859_1);
            Matcher viewport=Pattern.compile("(?is)<meta\\b[^>]*\\bname\\s*=\\s*(['\"]?)viewport\\1[^>]*>").matcher(head);
            byte[] meta="<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, viewport-fit=cover\">".getBytes(StandardCharsets.US_ASCII);
            int replaceStart,replaceEnd;
            if(viewport.find()){replaceStart=headStart+viewport.start();replaceEnd=headStart+viewport.end();}
            else{replaceStart=headTagEnd+1;replaceEnd=replaceStart;}
            String lowerHead=head.toLowerCase(Locale.ROOT);
            byte[] imageServerHints=(lowerHead.contains("art.sintention.com")&&lowerHead.contains("preconnect"))
                    ?new byte[0]
                    :"<link rel=\"dns-prefetch\" href=\"//art.sintention.com\"><link rel=\"preconnect\" href=\"https://art.sintention.com\" crossorigin>".getBytes(StandardCharsets.US_ASCII);
            ByteArrayOutputStream patched=new ByteArrayOutputStream(original.length+meta.length+imageServerHints.length+16);
            patched.write(original,0,replaceStart);
            patched.write(imageServerHints);
            patched.write(meta);
            patched.write(original,replaceEnd,original.length-replaceEnd);
            return new SequenceInputStream(new ByteArrayInputStream(patched.toByteArray()),source);
        }
        static int indexOfIgnoreCase(byte[] data,String needle,int from,int limit){
            byte[] p=needle.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.US_ASCII);
            for(int i=from;i<=limit-p.length;i++){
                boolean match=true;
                for(int j=0;j<p.length;j++){
                    int ch=data[i+j]&0xff;if(ch>='A'&&ch<='Z')ch+=32;
                    if(ch!=(p[j]&0xff)){match=false;break;}
                }
                if(match)return i;
            }
            return -1;
        }
        static int indexOfByte(byte[] data,byte target,int from,int limit){
            for(int i=from;i<limit;i++)if(data[i]==target)return i;
            return -1;
        }
        static String normal(String raw){if(raw==null||raw.isEmpty())return null;List<String> p=Uri.parse("https://x.invalid/"+raw).getPathSegments();if(p.isEmpty())return null;for(String s:p)if(s==null||s.isEmpty()||s.equals(".")||s.equals("..")||s.indexOf('\\')>=0||s.indexOf('\0')>=0)return null;return String.join("/",p);}
        java.util.Map<String,String> headers(String path){
            java.util.Map<String,String> h=new java.util.HashMap<>();
            if(cacheableMedia(path))h.put("Cache-Control","private, max-age=86400");
            else{h.put("Cache-Control","no-store, no-cache, must-revalidate");h.put("Pragma","no-cache");}
            h.put("Access-Control-Allow-Origin",origin);h.put("X-Content-Type-Options","nosniff");return h;
        }
        static boolean cacheableMedia(String path){
            if(path==null)return false;String p=path.toLowerCase(Locale.ROOT);
            return p.endsWith(".png")||p.endsWith(".jpg")||p.endsWith(".jpeg")||p.endsWith(".webp")||p.endsWith(".gif")||p.endsWith(".avif")||p.endsWith(".svg")||p.endsWith(".woff")||p.endsWith(".woff2")||p.endsWith(".ttf")||p.endsWith(".otf");
        }
        WebResourceResponse response(int c,String r,String m,String s){return new WebResourceResponse(m,"UTF-8",c,r,headers(null),new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8)));}
        static boolean text(String m){return m.startsWith("text/")||m.contains("javascript")||m.contains("json")||m.contains("xml")||m.contains("svg");}
        static String mime(String p){p=p.toLowerCase(Locale.ROOT);if(p.endsWith(".html"))return"text/html";if(p.endsWith(".js")||p.endsWith(".mjs"))return"application/javascript";if(p.endsWith(".css"))return"text/css";if(p.endsWith(".json"))return"application/json";if(p.endsWith(".svg"))return"image/svg+xml";if(p.endsWith(".png"))return"image/png";if(p.endsWith(".jpg")||p.endsWith(".jpeg"))return"image/jpeg";if(p.endsWith(".webp"))return"image/webp";if(p.endsWith(".gif"))return"image/gif";if(p.endsWith(".avif"))return"image/avif";if(p.endsWith(".woff2"))return"font/woff2";if(p.endsWith(".ttf"))return"font/ttf";if(p.endsWith(".wasm"))return"application/wasm";if(p.endsWith(".mp4"))return"video/mp4";if(p.endsWith(".webm"))return"video/webm";if(p.endsWith(".mp3"))return"audio/mpeg";if(p.endsWith(".ogg"))return"audio/ogg";if(p.endsWith(".wav"))return"audio/wav";if(p.endsWith(".txt"))return"text/plain";return"application/octet-stream";}
    }
    private final class SafTree{
        private static final int MAX_CACHED_DIRECTORIES=2048;
        private static final int MAX_CACHED_CHILDREN=100000;
        private final Uri tree;private final String rootId;
        private final SafImageCache imageCache = new SafImageCache(MainActivity.this);
        private final java.util.concurrent.atomic.AtomicInteger imageTimingSamples = new java.util.concurrent.atomic.AtomicInteger();
        private static final int MAX_CONCURRENT_DIRECTORY_QUERIES = 4;
        private final Object directoryIndexLock=new Object();
        private final java.util.LinkedHashMap<String,java.util.Map<String,Node>> directoryIndexCache =
                new java.util.LinkedHashMap<>(16, 0.75f, true);
        private final java.util.Map<String,java.util.Map<String,Node>> caseInsensitiveDirectoryCache = new java.util.HashMap<>();
        private final java.util.concurrent.ConcurrentHashMap<String,java.util.concurrent.FutureTask<java.util.Map<String,Node>>> directoryLoads =
                new java.util.concurrent.ConcurrentHashMap<>();
        private final java.util.concurrent.Semaphore directoryQuerySlots =
                new java.util.concurrent.Semaphore(MAX_CONCURRENT_DIRECTORY_QUERIES, true);
        private final java.util.concurrent.atomic.AtomicLong directoryIndexGeneration =
                new java.util.concurrent.atomic.AtomicLong();
        private final Object modIdsLock = new Object();
        private volatile List<String> cachedModIds;
        private volatile long cachedModIdsGeneration = -1L;
        private int cachedDirectoryChildren=0;
        SafTree(Uri u){tree=u;rootId=DocumentsContract.getTreeDocumentId(u);}
        String rootName(){try{return node(rootId).name;}catch(Exception e){return"Wayward";}}
        List<String> rootHtmlFiles()throws Exception{
            List<String> names=new ArrayList<>();
            for(Node n:children(rootId))if(!n.dir){
                String lower=n.name.toLowerCase(Locale.ROOT);
                if(lower.endsWith(".html")||lower.endsWith(".htm"))names.add(n.name);
            }
            return names;
        }
        boolean exists(String p){try{Node n=resolve(p);return n!=null&&!n.dir;}catch(Exception e){return false;}}
        InputStream open(String p)throws Exception{Node n=resolve(p);if(n==null||n.dir)return null;return getContentResolver().openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree,n.id));}
        InputStream openImage(String p)throws Exception{
            long resolveStarted=System.nanoTime();
            String normalized=FolderHandler.normal(p);
            String directDocumentId=null;
            try{
                if(tree!=null&&normalized!=null){
                    directDocumentId=SafImageDocumentResolver.buildDocumentId(
                            tree.getAuthority(),DocumentsContract.getTreeDocumentId(tree),normalized);
                }
            }catch(RuntimeException ignored){}
            String resolverMode;
            Node n;
            if(directDocumentId!=null){
                // ExternalStorageProvider document IDs are volume-relative paths.
                // Resolve the one requested document directly; never enumerate the
                // character directory (which may contain tens of thousands of files).
                resolverMode="external-storage-direct";
                Uri documentUri=DocumentsContract.buildDocumentUriUsingTree(tree,directDocumentId);
                n=queryImageDocument(documentUri,directDocumentId);
            }else{
                // Keep compatibility with non-filesystem SAF providers whose document
                // IDs are opaque and cannot be derived from a relative path.
                resolverMode="provider-directory-index";
                n=resolveImageViaProvider(p);
            }
            long resolveMs=(System.nanoTime()-resolveStarted)/1_000_000L;
            if(n==null||n.dir){
                recordImageOpenTiming(p,resolveMs,0L,null,-1L,resolverMode);
                return null;
            }
            long accessStarted=System.nanoTime();
            Uri documentUri=DocumentsContract.buildDocumentUriUsingTree(tree,n.id);
            SafImageCache.OpenResult opened=imageCache.open(getContentResolver(),documentUri,n.id,n.size,n.lastModified);
            long accessMs=(System.nanoTime()-accessStarted)/1_000_000L;
            recordImageOpenTiming(p,resolveMs,accessMs,opened,n.size,resolverMode);
            return opened==null?null:opened.stream;
        }
        private Node queryImageDocument(Uri documentUri,String expectedId)throws Exception{
            try(Cursor c=getContentResolver().query(documentUri,new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
            },null,null,null)){
                if(c==null||!c.moveToFirst())return null;
                int idIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mimeIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                int sizeIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
                int modifiedIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
                String actualId=idIndex>=0?c.getString(idIndex):null;
                if(actualId==null||!expectedId.equals(actualId))return null;
                String name=nameIndex>=0?c.getString(nameIndex):"";
                String mime=mimeIndex>=0?c.getString(mimeIndex):null;
                long size=sizeIndex>=0&&!c.isNull(sizeIndex)?c.getLong(sizeIndex):-1L;
                long modified=modifiedIndex>=0&&!c.isNull(modifiedIndex)?c.getLong(modifiedIndex):-1L;
                return new Node(actualId,name,DocumentsContract.Document.MIME_TYPE_DIR.equals(mime),size,modified);
            }
        }
        private Node resolveImageViaProvider(String path)throws Exception{
            String p=FolderHandler.normal(path);if(p==null)return null;
            String parent=rootId;Node n=null;String[] parts=p.split("/");
            for(int i=0;i<parts.length;i++){
                n=findIgnoreCase(parent,parts[i]);if(n==null)return null;
                if(i<parts.length-1){if(!n.dir)return null;parent=n.id;}
            }
            return n;
        }
        private void recordImageOpenTiming(String path,long resolveMs,long accessMs,SafImageCache.OpenResult opened,long imageSize,String resolverMode){
            int sample=imageTimingSamples.getAndIncrement();
            if(sample>=96&&resolveMs<350L&&accessMs<350L)return;
            JSONObject details=new JSONObject();
            try{
                details.put("elapsedMs",resolveMs+accessMs);
                details.put("resolveImageMs",resolveMs);
                details.put("imageAccessMs",accessMs);
                details.put("resolverMode",resolverMode);
                if(opened!=null){
                    details.put("cacheState",opened.cacheState);
                    details.put("openInputStreamMs",opened.openInputStreamMs);
                    details.put("cacheWaitMs",opened.cacheWaitMs);
                    details.put("cacheOpenMs",opened.cacheOpenMs);
                }else{
                    details.put("cacheState","missing");
                }
                if(imageSize>=0L)details.put("imageSizeBytes",imageSize);
                ImagePipelineDiagnostics.addSanitizedPath(details,"/"+path);
            }catch(Exception ignored){}
            ImagePipelineDiagnostics.record(MainActivity.this,"saf_image_open_timing",details);
        }
        private void recordDirectoryQueryTiming(long waitMs,long queryMs,int childCount){
            if(waitMs<250L&&queryMs<250L)return;
            JSONObject details=new JSONObject();
            try{
                details.put("elapsedMs",waitMs+queryMs);
                details.put("directoryWaitMs",waitMs);
                details.put("directoryQueryMs",queryMs);
                details.put("directoryChildCount",childCount);
            }catch(Exception ignored){}
            ImagePipelineDiagnostics.record(MainActivity.this,"saf_directory_query_timing",details);
        }

        String imageStudioModId() throws Exception {
            // The game folder supplies only the WML adapter marker.
            // The actual server is always installed from the launcher APK.
            Node modDirectory = resolve("wml/mods/imagestudio");
            if (modDirectory == null || !modDirectory.dir) return null;
            Node modScript = find(modDirectory.id, "mod.js");
            if (modScript == null || modScript.dir || !"imagestudio".equals(declared(modScript))) return null;
            return "imagestudio";
        }

        List<String> listModIds()throws Exception{
            long generation=directoryIndexGeneration.get();
            List<String> cached=cachedModIds;
            if(cached!=null&&cachedModIdsGeneration==generation)return new ArrayList<>(cached);
            synchronized(modIdsLock){
                generation=directoryIndexGeneration.get();
                cached=cachedModIds;
                if(cached!=null&&cachedModIdsGeneration==generation)return new ArrayList<>(cached);
                List<String> ids=new ArrayList<>();
                Node mods=resolve("wml/mods");
                if(mods!=null&&mods.dir){
                    for(Node d:children(mods.id)){
                        if(!d.dir||!ID.matcher(d.name).matches())continue;
                        Node f=find(d.id,"mod.js");
                        if(f==null||f.dir)continue;
                        String id=declared(f);
                        if(id!=null&&(id.isEmpty()||id.equals(d.name)))ids.add(d.name);
                    }
                }
                Collections.sort(ids);
                if(directoryIndexGeneration.get()==generation){
                    cachedModIds=Collections.unmodifiableList(new ArrayList<>(ids));
                    cachedModIdsGeneration=generation;
                }
                return ids;
            }
        }
        String declared(Node f){
            try{Uri u=DocumentsContract.buildDocumentUriUsingTree(tree,f.id);byte[] b=new byte[65536];int used=0;try(InputStream in=getContentResolver().openInputStream(u)){if(in==null)return null;while(used<b.length){int n=in.read(b,used,b.length-used);if(n<0)break;used+=n;}}
                String s=new String(b,0,used,StandardCharsets.UTF_8);int at=s.indexOf("WML.define");if(at<0)return null;Matcher m=MOD_ID.matcher(s.substring(at));return m.find()?m.group(1):"";
            }catch(Exception e){return null;}
        }
        Node resolve(String path)throws Exception{String p=FolderHandler.normal(path);if(p==null)return null;String parent=rootId;Node n=null;String[] parts=p.split("/");for(int i=0;i<parts.length;i++){n=find(parent,parts[i]);if(n==null)return null;if(i<parts.length-1){if(!n.dir)return null;parent=n.id;}}return n;}
        Node find(String parent,String name)throws Exception{return childIndex(parent).get(name);}
        private Node findIgnoreCase(String parent,String name)throws Exception{
            long generation=directoryIndexGeneration.get();
            java.util.Map<String,Node> index=childIndex(parent);
            Node exact=index.get(name);if(exact!=null)return exact;
            String key=name.toLowerCase(Locale.ROOT);
            synchronized(directoryIndexLock){
                java.util.Map<String,Node> folded=caseInsensitiveDirectoryCache.get(parent);
                if(folded==null){
                    java.util.Map<String,Node> built=new java.util.HashMap<>();
                    Set<String> ambiguous=new HashSet<>();
                    for(Node candidate:index.values()){
                        String candidateKey=candidate.name.toLowerCase(Locale.ROOT);
                        if(ambiguous.contains(candidateKey))continue;
                        Node previous=built.put(candidateKey,candidate);
                        if(previous!=null){
                            built.remove(candidateKey);
                            ambiguous.add(candidateKey);
                        }
                    }
                    folded=built;
                    if(directoryIndexGeneration.get()==generation&&directoryIndexCache.containsKey(parent)){
                        caseInsensitiveDirectoryCache.put(parent,folded);
                    }
                }
                return folded.get(key);
            }
        }
        List<Node> children(String parent)throws Exception{return new ArrayList<>(childIndex(parent).values());}
        java.util.Map<String,Node> childIndex(String parent)throws Exception{
            long generation;
            synchronized(directoryIndexLock){
                java.util.Map<String,Node> cached=directoryIndexCache.get(parent);
                if(cached!=null)return cached;
                generation=directoryIndexGeneration.get();
            }
            java.util.concurrent.FutureTask<java.util.Map<String,Node>> task =
                    new java.util.concurrent.FutureTask<>(() -> loadDirectoryIndex(parent,generation));
            java.util.concurrent.FutureTask<java.util.Map<String,Node>> active=directoryLoads.putIfAbsent(parent,task);
            if(active==null){active=task;task.run();}
            try{
                return active.get();
            }catch(InterruptedException error){
                Thread.currentThread().interrupt();
                throw error;
            }catch(java.util.concurrent.ExecutionException error){
                Throwable cause=error.getCause();
                if(cause instanceof Exception)throw (Exception)cause;
                if(cause instanceof Error)throw (Error)cause;
                throw new IllegalStateException("SAF 디렉터리 조회 실패",cause);
            }finally{
                directoryLoads.remove(parent,active);
            }
        }
        private java.util.Map<String,Node> loadDirectoryIndex(String parent,long generation)throws Exception{
            java.util.Map<String,Node> loaded=new java.util.LinkedHashMap<>();
            long waitStarted=System.nanoTime();
            long waitMs=0L;
            long queryMs=0L;
            boolean acquired=false;
            try{
                directoryQuerySlots.acquire();
                acquired=true;
                waitMs=(System.nanoTime()-waitStarted)/1_000_000L;
                long queryStarted=System.nanoTime();
                try{
                    Uri u=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
                    try(Cursor c=getContentResolver().query(u,new String[]{
                            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            DocumentsContract.Document.COLUMN_MIME_TYPE,
                            DocumentsContract.Document.COLUMN_SIZE,
                            DocumentsContract.Document.COLUMN_LAST_MODIFIED
                    },null,null,null)){
                        if(c!=null){
                            int idIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                            int nameIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                            int mimeIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                            int sizeIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
                            int modifiedIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
                            while(c.moveToNext()){
                                String name=nameIndex>=0?c.getString(nameIndex):null;
                                if(name==null||name.isEmpty())continue;
                                String id=idIndex>=0?c.getString(idIndex):null;
                                String mime=mimeIndex>=0?c.getString(mimeIndex):null;
                                long size=sizeIndex>=0&&!c.isNull(sizeIndex)?c.getLong(sizeIndex):-1L;
                                long modified=modifiedIndex>=0&&!c.isNull(modifiedIndex)?c.getLong(modifiedIndex):-1L;
                                loaded.put(name,new Node(id,name,DocumentsContract.Document.MIME_TYPE_DIR.equals(mime),size,modified));
                            }
                        }
                    }
                }finally{
                    queryMs=(System.nanoTime()-queryStarted)/1_000_000L;
                }
            }finally{
                if(acquired)directoryQuerySlots.release();
            }
            recordDirectoryQueryTiming(waitMs,queryMs,loaded.size());
            synchronized(directoryIndexLock){
                if(directoryIndexGeneration.get()!=generation)return loaded;
                java.util.Map<String,Node> existing=directoryIndexCache.get(parent);
                if(existing!=null)return existing;
                if(loaded.size()<=MAX_CACHED_CHILDREN){
                    while(directoryIndexCache.size()>=MAX_CACHED_DIRECTORIES
                            ||cachedDirectoryChildren+loaded.size()>MAX_CACHED_CHILDREN){
                        java.util.Iterator<java.util.Map.Entry<String,java.util.Map<String,Node>>> iterator=directoryIndexCache.entrySet().iterator();
                        if(!iterator.hasNext())break;
                        java.util.Map.Entry<String,java.util.Map<String,Node>> eldest=iterator.next();
                        iterator.remove();
                        caseInsensitiveDirectoryCache.remove(eldest.getKey());
                        cachedDirectoryChildren-=eldest.getValue().size();
                    }
                    directoryIndexCache.put(parent,loaded);
                    cachedDirectoryChildren+=loaded.size();
                }
            }
            return loaded;
        }
        void invalidateDirectoryIndex(){
            synchronized(directoryIndexLock){
                directoryIndexGeneration.incrementAndGet();
                directoryIndexCache.clear();
                caseInsensitiveDirectoryCache.clear();
                cachedDirectoryChildren=0;
            }
            directoryLoads.clear();
            cachedModIds=null;
            cachedModIdsGeneration=-1L;
        }
        Node node(String id)throws Exception{
            Uri u=DocumentsContract.buildDocumentUriUsingTree(tree,id);
            try(Cursor c=getContentResolver().query(u,new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
            },null,null,null)){
                if(c==null||!c.moveToFirst())return new Node(id,"Wayward",true,-1L,-1L);
                int idIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mimeIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                int sizeIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
                int modifiedIndex=c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
                String nodeId=idIndex>=0?c.getString(idIndex):id;
                String name=nameIndex>=0?c.getString(nameIndex):"Wayward";
                String mime=mimeIndex>=0?c.getString(mimeIndex):null;
                long size=sizeIndex>=0&&!c.isNull(sizeIndex)?c.getLong(sizeIndex):-1L;
                long modified=modifiedIndex>=0&&!c.isNull(modifiedIndex)?c.getLong(modifiedIndex):-1L;
                return new Node(nodeId,name,DocumentsContract.Document.MIME_TYPE_DIR.equals(mime),size,modified);
            }
        }
    }
    private static final class Node{
        final String id,name;
        final boolean dir;
        final long size,lastModified;
        Node(String i,String n,boolean d){this(i,n,d,-1L,-1L);}
        Node(String i,String n,boolean d,long s,long m){id=i;name=n;dir=d;size=s;lastModified=m;}
    }
}
